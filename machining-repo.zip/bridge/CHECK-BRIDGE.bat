@echo off
title NIDC Haas Bridge - Status Check
echo.
echo  ==================================================
echo    NIDC HAAS BRIDGE  -  Status Check
echo  ==================================================
echo.

echo  [1] Is Node.js installed?
where node >nul 2>nul
if errorlevel 1 (
  echo      NO - install it from https://nodejs.org
  goto end
) else (
  for /f "tokens=*" %%v in ('node --version') do echo      YES  %%v
)

echo.
echo  [2] Is the bridge running right now?
tasklist /fi "imagename eq node.exe" 2>nul | find /i "node.exe" >nul
if errorlevel 1 (
  echo      NO - the bridge is NOT running.
  echo      Fix: double-click RUN-FOREVER.bat
) else (
  echo      YES - node.exe is running.
)

echo.
echo  [3] Is the dashboard answering on port 8088?
powershell -NoProfile -Command "try{$r=Invoke-WebRequest -Uri 'http://localhost:8088' -TimeoutSec 4 -UseBasicParsing;Write-Host '     YES - dashboard is up (HTTP' $r.StatusCode ')'}catch{Write-Host '     NO  - nothing answering on 8088'}"

echo.
echo  [4] Can this PC reach each machine on port 8082?
for %%M in (192.168.1.17 192.168.1.18 192.168.1.20 192.168.1.21) do (
  powershell -NoProfile -Command "$t=Test-NetConnection -ComputerName %%M -Port 8082 -WarningAction SilentlyContinue; if($t.TcpTestSucceeded){Write-Host '     OK      %%M  - reachable'}else{Write-Host '     FAILED  %%M  - no answer (check machine is on + Setting 143)'}"
)

echo.
echo  [5] Is auto-start installed?
if exist "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\NIDC-Haas-Bridge.vbs" (
  echo      YES - it will start on boot.
) else (
  echo      NO  - run INSTALL-AUTOSTART.bat to enable it.
)

:end
echo.
echo  ==================================================
pause
