@echo off
echo ================================================
echo   NIDC Haas Bridge - Install Auto-Start
echo ================================================
echo.
echo This will make the bridge start AUTOMATICALLY
echo every time this PC turns on.
echo No black window - runs silently in background.
echo.

REM Get the folder where this .bat file lives
set BRIDGE_DIR=%~dp0

REM Startup folder path
set STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup

REM Copy the silent launcher shortcut to startup folder
copy /Y "%BRIDGE_DIR%start-silent.vbs" "%STARTUP%\NIDC-Haas-Bridge.vbs" >nul

if exist "%STARTUP%\NIDC-Haas-Bridge.vbs" (
    echo SUCCESS! Bridge will now start automatically on every boot.
    echo.
    echo To verify it's running after restart:
    echo   Open browser -^> http://localhost:8088
    echo.
    echo To REMOVE auto-start, run REMOVE-AUTOSTART.bat
) else (
    echo ERROR: Could not install. Try right-clicking and
    echo "Run as administrator"
)
echo.
pause
