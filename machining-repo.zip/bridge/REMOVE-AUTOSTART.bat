@echo off
echo Removing NIDC Haas Bridge auto-start...
set STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup
if exist "%STARTUP%\NIDC-Haas-Bridge.vbs" (
    del "%STARTUP%\NIDC-Haas-Bridge.vbs"
    echo Done - bridge will no longer auto-start.
) else (
    echo Auto-start was not installed.
)
echo.
pause
