@echo off
REM ====================================================================
REM   NIDC HAAS BRIDGE - watchdog runner
REM   Restarts the bridge automatically if it ever stops.
REM ====================================================================
title NIDC Haas Bridge (auto-restart)
cd /d "%~dp0"

if not exist "node_modules" call npm install

:loop
echo.
echo [%date% %time%] Starting bridge...
node bridge.js
echo.
echo [%date% %time%] Bridge stopped. Restarting in 15 seconds...
echo Close this window to stop for good.
timeout /t 15 /nobreak >nul
goto loop
