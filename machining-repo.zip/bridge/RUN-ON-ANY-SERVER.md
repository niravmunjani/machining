# Running the NIDC bridge on any server

The bridge must sit on the **same network as the machines** (it talks to
192.168.1.x). Beyond that it runs anywhere - Windows, Linux, a Pi, a NAS,
a VM, a Docker host.

All settings now come from a `.env` file, so the same code runs everywhere
with no editing of bridge.js.

---

## Option 1 - Docker  (any server with Docker)

    cp .env.example .env
    nano .env                 # put your machine IPs in
    docker compose up -d

Check it:

    docker compose logs -f
    http://SERVER-IP:8088

It restarts by itself if it crashes, and starts again when the server reboots.
`network_mode: host` is required so the container can see the shop LAN.

---

## Option 2 - Linux or Raspberry Pi  (no Docker)

    sudo bash install-linux.sh

First run creates `.env` and stops so you can edit it. Edit, then run it again.
Installs a systemd service that starts on boot and restarts on crash.

    journalctl -u nidc-bridge -f     # live logs
    sudo systemctl stop nidc-bridge  # stop

---

## Option 3 - Windows  (what you have now)

    RUN-FOREVER.bat          start, with auto-restart
    INSTALL-AUTOSTART.bat    start on every boot
    CHECK-BRIDGE.bat         diagnose
    TEST-PUSH.bat            test the cloud connection only

---

## Settings (.env)

| Variable | What it does | Example |
|---|---|---|
| `NIDC_MACHINES` | machines to watch | `M453@192.168.1.17,M432@192.168.1.18` |
| `NIDC_POLL_SECS` | seconds between checks | `5` |
| `NIDC_PORT` | local dashboard port | `8088` |
| `SUPABASE_URL` | your database | `https://xxx.supabase.co` |
| `SUPABASE_KEY` | database key | `eyJ...` |
| `NIDC_PUSH` | `false` turns off cloud sync | `true` |

Add a machine by appending to `NIDC_MACHINES` and restarting. Port defaults to
8082 if you leave it off.

---

## Moving it to a different server

1. Copy this folder across
2. Make sure the new server is on the shop network
3. Start it with whichever option above suits that machine
4. Stop the old one

The data lives in Supabase, not on the server, so nothing is lost in the move.
