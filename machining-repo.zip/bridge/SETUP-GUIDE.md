# NIDC Haas Bridge v2 — Setup Guide

Monitors **all 5 Haas machines** at once. Reads live data from each machine,
tracks parts and OEE, keeps history, and shows everything on one dashboard
in your web browser. No database, no cloud — runs on one office PC.

---

## The 5 machines it monitors

| Machine | IP Address |
|---------|------------|
| HAAS 1 (VF-3SS) | 192.168.1.17 |
| HAAS 2 | 192.168.1.18 |
| HAAS 3 | 192.168.1.20 |
| HAAS 4 | 192.168.1.21 |
| HAAS 5 | 192.168.1.19  *(placeholder — see note below)* |

**Note on HAAS 5:** its IP is a guess. When you find the real one, open
`bridge.js` in Notepad, find the HAAS 5 line near the top, fix the IP,
save, and restart.

---

## Step 1 — Install Node.js (one time, ~5 min)

Node.js is the free engine that runs the bridge.

1. Open a browser, go to **https://nodejs.org**
2. Click the big button that says **LTS**
3. Run the downloaded installer
4. Click **Next** through every screen, accept the defaults, then **Install**
5. Click **Finish**

You never have to touch Node.js again.

---

## Step 2 — Start the bridge

1. Put the `haas-bridge` folder somewhere easy, like the Desktop
2. Double-click **START-HERE.bat**
3. A black window opens. First time only, it spends a minute installing — normal
4. When you see **"Dashboard ready -> http://localhost:8088"**, it's running
5. **Leave that black window open.** Closing it stops monitoring.

---

## Step 3 — Open the dashboard

1. Open any browser on that PC
2. Go to: **http://localhost:8088**

To view it from another computer on the shop network, use the office PC's
own IP instead, e.g. `http://192.168.1.50:8088` (find the office PC's IP by
running `ipconfig` in a Command Prompt).

---

## What the dashboard shows

**Top strip — whole plant at a glance:**
- How many machines are Running / Idle / Alarm-or-Off
- Total parts made today across all machines
- Average OEE across all machines

**One tile per machine:**
- Colored left edge — green running, amber idle, red alarm, grey offline
- Active program, run status, alarm state, network address
- Parts today, average cycle time, run time
- OEE bar with Availability / Performance / Quality
- Recent activity log (parts, alarms, program changes)

The page refreshes itself every 5 seconds. History saves to `haas-data.json`
in the folder, so nothing is lost on restart.

---

## If a machine shows OFFLINE

That machine can't be reached. Check, in order:

1. Is the machine powered on?
2. From the office PC browser, try the machine's feed directly, e.g.
   `http://192.168.1.18:8082/current` — you should see XML.
3. If the XML doesn't load, that machine likely needs **Setting 143**
   turned on (a 5-minute fix at the Haas control). Ask Claude for the steps.
4. If the IP is wrong, fix it in `bridge.js` (CONFIG block at the top).

The other machines keep working fine even if one is offline.

---

## Changing settings

Open `bridge.js` in Notepad. The **CONFIG** block at the top has everything,
each with a plain-English comment:

- `machines` — the list of machines, their names and IPs
- `pollSeconds` — how often to check each machine (default 5)
- `idealCycleSeconds` — fastest a good part runs (OEE Performance)
- `plannedMinutesPerDay` — scheduled run minutes per day (OEE Availability)

Save the file and restart the bridge.

---

## What's next

Once all 5 machines show live data, the next step is connecting this into
CastFlow so the data flows into your production dashboard and daily revenue
tracker. Tell Claude when you're ready.
