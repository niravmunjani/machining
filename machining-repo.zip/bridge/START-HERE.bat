@echo off
REM ====================================================================
REM   NIDC HAAS BRIDGE v2 - one-click start for Windows
REM   Just double-click this file.
REM ====================================================================
title NIDC Haas Bridge
cd /d "%~dp0"

echo.
echo  ==================================================
echo    NIDC HAAS BRIDGE v2  -  all machines
echo  ==================================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo  ERROR: Node.js is not installed.
  echo.
  echo  Please install it first:
  echo    1. Go to  https://nodejs.org
  echo    2. Download the "LTS" version
  echo    3. Run the installer, click Next through all steps
  echo    4. Then double-click this file again
  echo.
  pause
  exit /b
)

if not exist "node_modules" (
  echo  First-time setup - installing components...
  echo.
  call npm install
  echo.
)

echo  Starting the bridge...
echo  When it says "Dashboard ready", open your browser to:
echo.
echo        http://localhost:8088
echo.
echo  Leave this window open. Close it to stop monitoring.
echo  ==================================================
echo.

node bridge.js

echo.
echo  The bridge has stopped.
pause
