@echo off
title NIDC - Supabase Push Test
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed. Get it from https://nodejs.org
  pause
  exit /b
)
node test-push.js
echo.
pause
