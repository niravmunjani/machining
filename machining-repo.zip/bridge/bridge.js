/* ==========================================================================
   NIDC HAAS BRIDGE  v2.1  -  Multi-machine monitor + Supabase live sync
   --------------------------------------------------------------------------
   Monitors all 4 Haas machines at NIDC. Reads live MTConnect data, tracks
   parts and OEE, keeps history, pushes live data to Supabase so the
   Machining Scheduler dashboard can show it from any device.

   Machine mapping:
     HAAS 1  =  M453   (192.168.1.17)
     HAAS 2  =  M432   (192.168.1.18)
     HAAS 3  =  M439   (192.168.1.20)
     HAAS 4  =  M440   (192.168.1.21)

   How to run:
     1. Install Node.js   (https://nodejs.org  - get the LTS version)
     2. Double-click START-HERE.bat
     3. Open a browser to  http://localhost:8088

   To change machine IPs, edit the CONFIG block right below.
   ========================================================================== */

const http  = require("http");
const https = require("https");
const fs    = require("fs");
const path  = require("path");
const { XMLParser } = require("fast-xml-parser");

/* ==========================================================================
   CONFIG  -  edit machine IPs here if they change
   ========================================================================== */
/* load .env if present, so plain "node bridge.js" works the same as docker */
(function loadDotEnv(){
  try{
    const fs_=require("fs"), p_=require("path");
    const f=p_.join(__dirname,".env");
    if(!fs_.existsSync(f)) return;
    fs_.readFileSync(f,"utf8").split(/\r?\n/).forEach(function(line){
      line=line.trim();
      if(!line||line[0]==="#") return;
      const eq=line.indexOf("=");
      if(eq<1) return;
      const k=line.slice(0,eq).trim(), v=line.slice(eq+1).trim();
      if(!(k in process.env)) process.env[k]=v;
    });
    console.log("[env] loaded .env");
  }catch(e){}
})();

const CONFIG = {
  // --- Your Haas machines --------------------------------------------------
  // Per-machine settings:
  //   idealCycleSeconds - fastest a GOOD part runs (seconds). null = auto-learn from data.
  //   qualityPct        - good parts / total parts × 100. Update this if you track scrap.
  //                       Haas MTConnect does not report scrap so default is 100.
  machines: [
    { id: "haas1", machineId: "M453", name: "HAAS 1 (M453)", ip: "192.168.1.17", port: 8082, idealCycleSeconds: null, qualityPct: 100 },
    { id: "haas2", machineId: "M432", name: "HAAS 2 (M432)", ip: "192.168.1.18", port: 8082, idealCycleSeconds: null, qualityPct: 100 },
    { id: "haas3", machineId: "M439", name: "HAAS 3 (M439)", ip: "192.168.1.20", port: 8082, idealCycleSeconds: null, qualityPct: 100 },
    { id: "haas4", machineId: "M440", name: "HAAS 4 (M440)", ip: "192.168.1.21", port: 8082, idealCycleSeconds: null, qualityPct: 100 },
  ],

  // --- How often to check each machine (seconds) --------------------------
  pollSeconds: 5,

  // How often to PUSH to the cloud. Polling the machines is local and free,
  // but every push rewrites rows in Supabase. The apps only refresh every
  // 10s, so pushing more often than this gains nothing and bloats the table.
  pushSeconds: 20,

  // --- Dashboard port ------------------------------------------------------
  dashboardPort: 8088,         // open http://localhost:8088 in a browser

  // --- OEE settings --------------------------------------------------------
  // Shift schedule - used to calculate Availability correctly
  // Availability = machine run time / elapsed planned time THIS SHIFT (not full day)
  // endHour > 24 means it crosses midnight (e.g. 30 = 6am next day)
  shifts: [
    { name: "1st Shift", startHour: 6,  endHour: 14 },   // 6:00 AM - 2:00 PM
    { name: "2nd Shift", startHour: 14, endHour: 22 },   // 2:00 PM - 10:00 PM
    { name: "3rd Shift", startHour: 22, endHour: 30 },   // 10:00 PM - 6:00 AM (30 = next day 6am)
  ],

  // --- Supabase (live sync to cloud so Scheduler can see data) -----------------
  supabaseUrl:    "https://rjklrzzpwrapxdahgidz.supabase.co",
  supabaseKey:    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJqa2xyenpwd3JhcHhkYWhnaWR6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM1MTgyMDEsImV4cCI6MjA4OTA5NDIwMX0.gl3fLz-AD4Xvrub9WRAVcOnc7DvCfvveBAz6wSigX1Y",
  supabaseTable:  "haas_live",
  pushToSupabase: true,    // set false to disable cloud sync

  // --- Data storage --------------------------------------------------------
  dataFile: path.join(__dirname, "haas-data.json"),
  maxEventsPerMachine: 3000,
};

/* ==========================================================================
   ENVIRONMENT OVERRIDES  -  lets the same code run on any server
   Nothing below changes behaviour unless you set the variable.
     NIDC_MACHINES   M453@192.168.1.17,M432@192.168.1.18,M439@192.168.1.20
     NIDC_POLL_SECS  5
     NIDC_PORT       8088
     SUPABASE_URL    https://xxxx.supabase.co
     SUPABASE_KEY    eyJ...
     NIDC_DATA_DIR   /data          (where haas-data.json is kept)
   ========================================================================== */
(function applyEnv(){
  const E = process.env;

  if (E.NIDC_MACHINES) {
    const list = E.NIDC_MACHINES.split(",").map(s => s.trim()).filter(Boolean);
    const parsed = [];
    list.forEach((entry, idx) => {
      const bits = entry.split("@");
      const mid  = (bits[0] || "").trim();
      const rest = (bits[1] || "").trim();
      if (!mid || !rest) return;
      const hp   = rest.split(":");
      parsed.push({
        id: "haas" + (idx + 1),
        machineId: mid,
        name: mid,
        ip: hp[0],
        port: hp[1] ? parseInt(hp[1], 10) : 8082,
        idealCycleSeconds: null,
        qualityPct: 100,
      });
    });
    if (parsed.length) {
      CONFIG.machines = parsed;
      console.log("[env] machines from NIDC_MACHINES: " +
        parsed.map(m => m.machineId + "@" + m.ip + ":" + m.port).join(", "));
    }
  }

  if (E.NIDC_POLL_SECS) CONFIG.pollSeconds   = parseInt(E.NIDC_POLL_SECS, 10) || CONFIG.pollSeconds;
  if (E.NIDC_PUSH_SECS) CONFIG.pushSeconds   = parseInt(E.NIDC_PUSH_SECS, 10) || CONFIG.pushSeconds;
  if (E.NIDC_PORT)      CONFIG.dashboardPort = parseInt(E.NIDC_PORT, 10)      || CONFIG.dashboardPort;
  if (E.SUPABASE_URL)   CONFIG.supabaseUrl   = E.SUPABASE_URL.replace(/\/+$/, "");
  if (E.SUPABASE_KEY)   CONFIG.supabaseKey   = E.SUPABASE_KEY;
  if (E.NIDC_PUSH === "false" || E.NIDC_PUSH === "0") CONFIG.pushToSupabase = false;
  if (E.NIDC_DATA_DIR)  CONFIG.dataFile      = require("path").join(E.NIDC_DATA_DIR, "haas-data.json");
})();


/* ==========================================================================
   DATA STORE
   ========================================================================== */
let store = { machines: {} };

function blankMachine(m) {
  return {
    id: m.id, machineId: m.machineId, name: m.name,
    events: [], cycles: [], daily: {}, shifts: {}, lastSnapshot: null,
  };
}

function loadStore() {
  try {
    if (fs.existsSync(CONFIG.dataFile)) {
      store = JSON.parse(fs.readFileSync(CONFIG.dataFile, "utf8"));
      log("Loaded existing data file.");
    } else {
      log("No data file yet - starting fresh.");
    }
  } catch (e) {
    log("WARNING: could not read data file, starting fresh. " + e.message);
    store = { machines: {} };
  }
  for (const m of CONFIG.machines) {
    if (!store.machines[m.id]) store.machines[m.id] = blankMachine(m);
    else {
      store.machines[m.id].name = m.name;
      store.machines[m.id].machineId = m.machineId;
    }
  }
}

let saveTimer = null;
function saveStore() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      for (const id of Object.keys(store.machines)) {
        const r = store.machines[id];
        if (r.events.length > CONFIG.maxEventsPerMachine)
          r.events = r.events.slice(-CONFIG.maxEventsPerMachine);
        if (r.cycles.length > CONFIG.maxEventsPerMachine)
          r.cycles = r.cycles.slice(-CONFIG.maxEventsPerMachine);
      }
      fs.writeFileSync(CONFIG.dataFile, JSON.stringify(store, null, 2));
    } catch (e) {
      log("WARNING: could not save data file. " + e.message);
    }
  }, 2000);
}

/* ==========================================================================
   LOGGING
   ========================================================================== */
function log(msg) {
  console.log("[" + new Date().toLocaleTimeString() + "] " + msg);
}

/* ==========================================================================
   XML PARSING
   ========================================================================== */
const xml = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: "@_" });

function findAll(node, tagName, results) {
  if (node == null || typeof node !== "object") return results;
  for (const key of Object.keys(node)) {
    if (key === tagName) {
      const v = node[key];
      if (Array.isArray(v)) results.push(...v);
      else results.push(v);
    }
    const child = node[key];
    if (Array.isArray(child)) child.forEach((c) => findAll(c, tagName, results));
    else if (typeof child === "object") findAll(child, tagName, results);
  }
  return results;
}

function valueByName(parsed, tagName, nameAttr) {
  for (const el of findAll(parsed, tagName, [])) {
    if (el && el["@_name"] === nameAttr)
      return el["#text"] !== undefined ? el["#text"] : el;
  }
  return null;
}

function readSnapshot(parsed) {
  const runStatus   = valueByName(parsed, "Execution",       "RunStatus");
  const mode        = valueByName(parsed, "ControllerMode",  "Mode");
  const program     = valueByName(parsed, "Program",         "Program");
  const alarm       = valueByName(parsed, "Message",         "ActiveAlarms");
  const m30         = valueByName(parsed, "Message",         "M30Counter1");
  const lastCycle   = valueByName(parsed, "AccumulatedTime", "LastCycle");
  const thisCycle   = valueByName(parsed, "AccumulatedTime", "ThisCycle");
  const spindleSpeed= valueByName(parsed, "SpindleSpeed",    "SpindleSpeed");
  const availability= valueByName(parsed, "Availability",    "Availability");
  const estop       = valueByName(parsed, "EmergencyStop",   "EmergencyStop");
  const feedOvr     = valueByName(parsed, "PathFeedrate",    "FeedrateOverride");

  return {
    time: new Date().toISOString(), online: true,
    runStatus:    runStatus    != null ? String(runStatus)    : "UNKNOWN",
    mode:         mode         != null ? String(mode)         : "UNKNOWN",
    program:      program      != null ? String(program)      : "-",
    alarm:        alarm        != null ? String(alarm)        : "UNKNOWN",
    partCount:    m30          != null ? Number(m30)          : null,
    lastCycleSec: lastCycle    != null ? Number(lastCycle)    : null,
    thisCycleSec: thisCycle    != null ? Number(thisCycle)    : null,
    spindleSpeed: spindleSpeed != null ? Number(spindleSpeed) : null,
    availability: availability != null ? String(availability) : "UNKNOWN",
    estop:        estop        != null ? String(estop)        : "UNKNOWN",
    feedOverride: feedOvr      != null ? Number(feedOvr)      : null,
  };
}

/* ==========================================================================
   HELPERS
   ========================================================================== */
function todayKey() { return new Date().toISOString().slice(0, 10); }

// Returns current shift info based on NIDC shift schedule:
//   1st Shift: 6:00 AM  - 2:00 PM
//   2nd Shift: 2:00 PM  - 10:00 PM
//   3rd Shift: 10:00 PM - 6:00 AM (next day)
function currentShift() {
  const h = new Date().getHours();
  if (h >= 6  && h < 14) return { name: "1st Shift", number: 1 };
  if (h >= 14 && h < 22) return { name: "2nd Shift", number: 2 };
  if (h >= 22 || h < 6)  return { name: "3rd Shift", number: 3 };
  return { name: "Off Hours", number: 0 };
}

// Unique key for the current shift period (used to bucket shift data)
function shiftKey() {
  const now = new Date();
  const h = now.getHours();
  // 3rd shift after midnight (0-6am) belongs to previous calendar day
  if (h >= 0 && h < 6) {
    const prev = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    return prev.toISOString().slice(0, 10) + "_S3";
  }
  const d = now.toISOString().slice(0, 10);
  if (h >= 6  && h < 14) return d + "_S1";
  if (h >= 14 && h < 22) return d + "_S2";
  if (h >= 22)            return d + "_S3";
  return d + "_S1";
}

function ensureDay(rec, key) {
  if (!rec.daily[key])
    rec.daily[key] = { runSeconds: 0, idleSeconds: 0, downSeconds: 0, parts: 0, alarms: 0 };
  return rec.daily[key];
}

function ensureShift(rec, key) {
  if (!rec.shifts) rec.shifts = {};
  if (!rec.shifts[key])
    rec.shifts[key] = {
      runSeconds: 0, idleSeconds: 0, downSeconds: 0, setupSeconds: 0,
      parts: 0, scrapParts: 0,
      feedOverrideSum: 0, feedOverrideSamples: 0,
    };
  return rec.shifts[key];
}

function addEvent(rec, type, detail) {
  rec.events.push({ time: new Date().toISOString(), type, detail });
  log(rec.name + " | " + type + (detail ? " - " + detail : ""));
}

function isRunning(status) {
  const s = (status || "").toUpperCase();
  return s === "EXECUTING" || s === "ACTIVE";
}

function alarmIsActive(alarm) {
  if (!alarm) return false;
  const a = alarm.toUpperCase();
  return a !== "NO ACTIVE ALARMS" && a !== "UNKNOWN" && a !== "-";
}

/* ==========================================================================
   POLLER
   ========================================================================== */
const prevByMachine = {};

function fetchFeed(m) {
  return new Promise((resolve, reject) => {
    const url = "http://" + m.ip + ":" + m.port + "/current";
    const req = http.get(url, { timeout: 8000 }, (res) => {
      let body = "";
      res.on("data", (c) => (body += c));
      res.on("end", () => resolve(body));
    });
    req.on("timeout", () => { req.destroy(); reject(new Error("timed out")); });
    req.on("error", (e) => reject(e));
  });
}

async function pollMachine(m) {
  const rec   = store.machines[m.id];
  const day   = ensureDay(rec, todayKey());
  const shKey = shiftKey();
  const shift = ensureShift(rec, shKey);
  const prev  = prevByMachine[m.id] || {};
  let snap;

  try {
    const body = await fetchFeed(m);
    const parsed = xml.parse(body);
    snap = readSnapshot(parsed);
  } catch (e) {
    snap = {
      time: new Date().toISOString(), online: false, runStatus: "OFFLINE",
      mode: "-", program: "-", alarm: "-", partCount: prev.partCount,
      lastCycleSec: null, thisCycleSec: null, spindleSpeed: null,
      availability: "UNAVAILABLE", estop: "-", feedOverride: null,
    };
    if (prev.online !== false) addEvent(rec, "OFFLINE", "Unreachable: " + e.message);
    day.downSeconds += CONFIG.pollSeconds;
    prevByMachine[m.id] = { ...prev, online: false };
    rec.lastSnapshot = snap;
    return;
  }

  if (prev.online === false) addEvent(rec, "ONLINE", "Reachable again");

  const alarmActive = alarmIsActive(snap.alarm);
  // Detect setup: machine stopped AND program changed since last poll
  const isSetup = !isRunning(snap.runStatus) && !alarmActive
                  && prev.program != null && snap.program !== prev.program;

  if (alarmActive) {
    day.downSeconds   += CONFIG.pollSeconds;
    shift.downSeconds += CONFIG.pollSeconds;
  } else if (isRunning(snap.runStatus)) {
    day.runSeconds   += CONFIG.pollSeconds;
    shift.runSeconds += CONFIG.pollSeconds;
  } else if (isSetup) {
    // Setup/tool change: machine idle due to program change
    day.idleSeconds    += CONFIG.pollSeconds;
    shift.idleSeconds  += CONFIG.pollSeconds;
    if (!shift.setupSeconds) shift.setupSeconds = 0;
    shift.setupSeconds += CONFIG.pollSeconds;
  } else {
    day.idleSeconds   += CONFIG.pollSeconds;
    shift.idleSeconds += CONFIG.pollSeconds;
  }

  // Track feed rate override (performance loss indicator)
  // 100% = full speed, 80% = running at 80% of programmed speed
  if (snap.feedOverride != null && snap.feedOverride > 0 && isRunning(snap.runStatus)) {
    if (!shift.feedOverrideSum)     shift.feedOverrideSum     = 0;
    if (!shift.feedOverrideSamples) shift.feedOverrideSamples = 0;
    shift.feedOverrideSum     += snap.feedOverride;
    shift.feedOverrideSamples += 1;
  }

  if (prev.partCount != null && snap.partCount != null && snap.partCount > prev.partCount) {
    const made = snap.partCount - prev.partCount;
    day.parts   += made;
    shift.parts += made;
    const cyc = snap.lastCycleSec || snap.thisCycleSec || null;
    if (cyc) rec.cycles.push({ time: snap.time, seconds: cyc });
    addEvent(rec, "PART_COMPLETE", made + " part(s), cycle " + (cyc ? cyc + "s" : "n/a"));
    // Log to haas_production_log for production tracking dashboard
    if (CONFIG.pushToSupabase) {
      logProductionCycle(m, snap, made, cyc, shKey).catch(e => log(m.name + " prod log error: " + e.message));
    }
  }

  // Downtime logging: alarm start
  if (prev.alarm != null && snap.alarm !== prev.alarm && alarmIsActive(snap.alarm)) {
    if (CONFIG.pushToSupabase) {
      startDowntimeLog(m, snap, shKey, "alarm").catch(e => {});
    }
  }
  // Downtime resolved
  if (prev.alarm != null && snap.alarm !== prev.alarm && !alarmIsActive(snap.alarm) && alarmIsActive(prev.alarm)) {
    if (CONFIG.pushToSupabase) {
      resolveDowntimeLog(m.machineId, "alarm").catch(e => {});
    }
  }
  // Machine went offline
  if (prev.online === true && snap.online === false) {
    if (CONFIG.pushToSupabase) {
      startDowntimeLog(m, snap, shKey, "offline").catch(e => {});
    }
  }

  if (prev.runStatus != null && snap.runStatus !== prev.runStatus)
    addEvent(rec, "STATE_CHANGE", prev.runStatus + " -> " + snap.runStatus);

  if (prev.alarm != null && snap.alarm !== prev.alarm) {
    if (alarmActive) { day.alarms += 1; addEvent(rec, "ALARM", snap.alarm); }
    else addEvent(rec, "ALARM_CLEARED", "Alarms cleared");
  }

  if (prev.program != null && snap.program !== prev.program)
    addEvent(rec, "PROGRAM_CHANGE", prev.program + " -> " + snap.program);

  prevByMachine[m.id] = {
    online: true, partCount: snap.partCount, runStatus: snap.runStatus,
    alarm: snap.alarm, program: snap.program,
  };
  rec.lastSnapshot = snap;
}

async function pollAll() {
  await Promise.all(
    CONFIG.machines.map((m) =>
      pollMachine(m).catch((e) => log(m.name + " poll error: " + e.message))
    )
  );
  saveStore();
  // Check if shift changed — auto-save completed shift summaries
  await checkShiftChanges().catch((e) => log("Shift check error: " + e.message));
  if (CONFIG.pushToSupabase && shouldPushNow()) {
    pushAllToSupabase().catch((e) => log("Supabase push error: " + e.message));
  }
}

/* --------------------------------------------------------------------------
   PUSH THROTTLE
   Polling the machines is local and costs nothing. Writing to Supabase does.
   So push on a slower clock, and skip entirely when nothing has changed -
   an idle machine with the same program and part count has nothing new to say.
   A heartbeat still goes out every 2 minutes so the app can tell the bridge
   is alive rather than dead.
   -------------------------------------------------------------------------- */
let _lastPushAt = 0;
let _lastSig    = "";

function machineSignature() {
  return CONFIG.machines.map((m) => {
    const rec  = store.machines[m.id] || {};
    const snap = rec.lastSnapshot || {};
    return [
      m.machineId,
      snap.online ? 1 : 0,
      snap.runStatus,
      snap.program,
      snap.partCount,
      snap.alarm,
      snap.estop,
    ].join("|");
  }).join("~");
}

function shouldPushNow() {
  const now  = Date.now();
  const secs = (now - _lastPushAt) / 1000;
  const sig  = machineSignature();

  if (secs < CONFIG.pushSeconds) return false;      // too soon
  if (sig === _lastSig && secs < 120) return false; // nothing changed, not due a heartbeat

  _lastPushAt = now;
  _lastSig    = sig;
  return true;
}

/* ==========================================================================
   OEE CALCULATION
   OEE = Availability x Performance x Quality
     Availability = machine run time THIS SHIFT / 8 hours  (resets every shift)
     Performance  = ideal cycle time x parts / actual run time
     Quality      = good parts / total parts (set qualityPct per machine in CONFIG)
   ========================================================================== */

const SHIFT_HOURS = 8;
const SHIFT_SECS  = SHIFT_HOURS * 3600; // 28,800 seconds per shift

// Best (fastest) cycle time seen -- used as ideal when not set in CONFIG
function autoIdealCycle(rec) {
  if (!rec.cycles || rec.cycles.length === 0) return null;
  const sorted = rec.cycles.map(c => c.seconds).sort((a, b) => a - b);
  const idx = Math.max(0, Math.floor(sorted.length * 0.10));
  return sorted[idx];
}

// OEE for a SINGLE SHIFT -- resets to 0 at every shift change
function computeShiftOEE(shiftData, rec, machineConfig) {
  const d  = shiftData || { runSeconds: 0, parts: 0 };
  const mc = machineConfig || {};

  // Availability = run seconds this shift / full 8-hour shift
  const availability = d.runSeconds / SHIFT_SECS;

  // Performance = ideal cycle x parts / run time
  const ideal = mc.idealCycleSeconds || autoIdealCycle(rec);
  let performance = 0;
  if (d.runSeconds > 0 && d.parts > 0) {
    performance = ideal ? (ideal * d.parts) / d.runSeconds : 1.0;
  }

  // Quality = good parts / total parts (default 100% -- no scrap data from MTConnect)
  const qualityPct = (mc && mc.qualityPct != null) ? mc.qualityPct : 100;
  const quality    = clamp(qualityPct / 100);
  const oee        = availability * performance * quality;
  return {
    availability: clamp(availability), performance: clamp(performance),
    quality: clamp(quality), oee: clamp(oee),
    idealCycle: ideal, qualityPct, parts: d.parts, runSeconds: d.runSeconds,
  };
}

// Daily OEE -- all shifts so far today combined
function computeOEE(rec, dayKey, machineConfig) {
  const d = rec.daily[dayKey];
  if (!d) return null;
  const mc = machineConfig || {};
  const h = new Date().getHours();
  let shiftsStarted = h < 6 ? 3 : h < 14 ? 1 : h < 22 ? 2 : 3;
  const plannedSec   = shiftsStarted * SHIFT_SECS;
  const availability = plannedSec > 0 ? d.runSeconds / plannedSec : 0;
  const ideal = mc.idealCycleSeconds || autoIdealCycle(rec);
  let performance = 0;
  if (d.runSeconds > 0 && d.parts > 0) {
    performance = ideal ? (ideal * d.parts) / d.runSeconds : 1.0;
  }
  const qualityPct = (mc && mc.qualityPct != null) ? mc.qualityPct : 100;
  const quality    = clamp(qualityPct / 100);
  const oee        = availability * performance * quality;
  return {
    availability: clamp(availability), performance: clamp(performance),
    quality: clamp(quality), oee: clamp(oee), plannedSec, idealCycle: ideal, qualityPct,
  };
}

function clamp(x) {
  if (isNaN(x) || x < 0) return 0;
  return x > 1 ? 1 : x;
}

/* ==========================================================================
   SUPABASE PUSH  -  sends live data to cloud so the Scheduler can read it
   ========================================================================== */
function supabaseUpsert(rows, table, conflictCol) {
  const tbl = table || CONFIG.supabaseTable;
  const col  = conflictCol || "machine_id";
  return new Promise((resolve, reject) => {
    const body = JSON.stringify(rows);
    const url  = new URL(CONFIG.supabaseUrl + "/rest/v1/" + tbl);
    const opts = {
      hostname: url.hostname,
      path:     url.pathname + "?on_conflict=" + col,
      method:   "POST",
      headers: {
        "Content-Type":  "application/json",
        "Content-Length": Buffer.byteLength(body),
        "apikey":         CONFIG.supabaseKey,
        "Authorization":  "Bearer " + CONFIG.supabaseKey,
        "Prefer":         "resolution=merge-duplicates",
      },
    };
    const req = https.request(opts, (res) => {
      let data = "";
      res.on("data", (c) => (data += c));
      res.on("end", () => {
        if (res.statusCode >= 200 && res.statusCode < 300) resolve();
        else reject(new Error("Supabase HTTP " + res.statusCode + ": " + data));
      });
    });
    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

/* ==========================================================================
   PRODUCTION & DOWNTIME LOGGING
   ========================================================================== */

// Active downtime records waiting to be resolved (machine_id -> insert id)
const activeDowntime = {};

async function logProductionCycle(m, snap, made, cycSec, shKey) {
  const cs = currentShift();
  const now = new Date();
  const shiftDate = shKey.split("_")[0];
  const cycleEnd  = now.toISOString();
  const cycleStart = cycSec ? new Date(now.getTime() - cycSec * 1000).toISOString() : null;

  const rows = [];
  for (let i = 0; i < made; i++) {
    rows.push({
      machine_id:       m.machineId,
      machine_name:     m.name,
      shift_date:       shiftDate,
      shift_name:       cs.name,
      shift_number:     cs.number,
      record_time:      now.toISOString(),
      cycle_end_time:   cycleEnd,
      cycle_start_time: cycleStart,
      actual_cycle_sec: cycSec || null,
      program_name:     snap.program && snap.program !== "-" ? snap.program : null,
      part_number:      snap.program && snap.program !== "-" ? snap.program : null,
      parts_made:       1,
      good_parts:       1,
      scrap_parts:      0,
      cumulative_parts: (snap.partCount || 0) - (made - 1 - i),
      spindle_speed:    snap.spindleSpeed || null,
      feed_override:    snap.feedOverride || null,
      run_status:       snap.runStatus    || null,
      machine_status:   "running",
    });
  }
  await supabaseInsert(rows, "haas_production_log");
}

async function startDowntimeLog(m, snap, shKey, dtype) {
  const cs = currentShift();
  const shiftDate = shKey.split("_")[0];
  const row = {
    machine_id:   m.machineId,
    machine_name: m.name,
    shift_date:   shiftDate,
    shift_name:   cs.name,
    shift_number: cs.number,
    start_time:   new Date().toISOString(),
    downtime_type: dtype,
    reason:       dtype === "alarm" ? (snap.alarm || "ALARM") : "OFFLINE",
    program_name: snap.program && snap.program !== "-" ? snap.program : null,
    resolved:     false,
  };
  const res = await supabaseInsert([row], "haas_downtime_log");
  // Keep the id AND the start time so the duration can be worked out on close
  if (res && res[0] && res[0].id) {
    activeDowntime[m.machineId + "_" + dtype] = {
      id: res[0].id,
      startedAt: row.start_time,
    };
  }
}

async function resolveDowntimeLog(machineId, dtype) {
  const key = machineId + "_" + dtype;
  const entry = activeDowntime[key];
  if (!entry) return;
  // older runs stored a bare id; cope with both shapes
  const id        = (typeof entry === "object") ? entry.id : entry;
  const startedAt = (typeof entry === "object") ? entry.startedAt : null;
  if (!id) return;

  const endTime = new Date().toISOString();
  // BUG FIX: duration_seconds was never being written, so every closed
  // stoppage recorded as 0 and all downtime reporting read as zero.
  let durationSec = null;
  if (startedAt) {
    durationSec = Math.max(0,
      Math.round((new Date(endTime).getTime() - new Date(startedAt).getTime()) / 1000));
  }

  const url = new URL(CONFIG.supabaseUrl + "/rest/v1/haas_downtime_log?id=eq." + id);
  const payload = { end_time: endTime, resolved: true };
  if (durationSec !== null) payload.duration_seconds = durationSec;
  const body = JSON.stringify(payload);
  await new Promise((resolve, reject) => {
    const opts = {
      hostname: url.hostname,
      path:     url.pathname + url.search,
      method:   "PATCH",
      headers: {
        "Content-Type":   "application/json",
        "Content-Length": Buffer.byteLength(body),
        "apikey":         CONFIG.supabaseKey,
        "Authorization":  "Bearer " + CONFIG.supabaseKey,
        "Prefer":         "return=minimal",
      },
    };
    const req = require("https").request(opts, res => { res.resume(); resolve(); });
    req.on("error", reject);
    req.write(body); req.end();
  });
  delete activeDowntime[key];
  if (durationSec !== null) {
    log(machineId + " " + dtype + " cleared after " +
        (durationSec >= 60 ? Math.round(durationSec/60) + " min" : durationSec + "s"));
  }
}

// Generic INSERT (no upsert, creates new rows each time)
function supabaseInsert(rows, table) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify(rows);
    const url  = new URL(CONFIG.supabaseUrl + "/rest/v1/" + table);
    const opts = {
      hostname: url.hostname,
      path:     url.pathname,
      method:   "POST",
      headers: {
        "Content-Type":   "application/json",
        "Content-Length": Buffer.byteLength(body),
        "apikey":         CONFIG.supabaseKey,
        "Authorization":  "Bearer " + CONFIG.supabaseKey,
        "Prefer":         "return=representation",
      },
    };
    const req = require("https").request(opts, res => {
      let data = "";
      res.on("data", c => (data += c));
      res.on("end", () => {
        try { resolve(JSON.parse(data)); } catch(e) { resolve(null); }
      });
    });
    req.on("error", reject);
    req.write(body); req.end();
  });
}

// Track which shift was active last poll, per machine
const prevShiftKeyByMachine = {};

// Called automatically when shift changes — saves completed shift to haas_shift_history
async function saveShiftSummary(m, completedShiftKey) {
  try {
    const rec = store.machines[m.id];
    if (!rec) return;
    const sh = rec.shifts && rec.shifts[completedShiftKey];
    if (!sh) return;
    if (sh.parts === 0 && sh.runSeconds === 0) return; // nothing to save

    const mc = CONFIG.machines.find(x => x.id === m.id) || {};
    const oee = computeShiftOEE(sh, rec, mc);

    // Parse "2026-06-01_S2" -> date="2026-06-01", num=2
    const parts = completedShiftKey.split("_");
    const shiftDate = parts[0];
    const shiftNum  = parts[1] === "S1" ? 1 : parts[1] === "S2" ? 2 : 3;
    const shiftNames = ["1st Shift", "2nd Shift", "3rd Shift"];

    const recent = rec.cycles.slice(-50);
    const avgCycle = recent.length
      ? recent.reduce((s, c) => s + c.seconds, 0) / recent.length : null;

    const row = {
      machine_id:   m.machineId,
      shift_date:   shiftDate,
      shift_number: shiftNum,
      shift_name:   shiftNames[shiftNum - 1],
      parts_made:   sh.parts          || 0,
      good_parts:   oee.goodParts     || sh.parts || 0,
      scrap_parts:  sh.scrapParts     || 0,
      run_seconds:  sh.runSeconds     || 0,
      idle_seconds: sh.idleSeconds    || 0,
      down_seconds: sh.downSeconds    || 0,
      setup_seconds:sh.setupSeconds   || 0,
      oee:          Math.round(oee.oee          * 1000) / 10,
      availability: Math.round(oee.availability * 1000) / 10,
      performance:  Math.round(oee.performance  * 1000) / 10,
      quality:      Math.round(oee.quality      * 1000) / 10,
      avg_cycle_sec:avgCycle ? Math.round(avgCycle * 10) / 10 : null,
      avg_feed_pct: oee.avgFeedPct || 100,
      saved_at:     new Date().toISOString(),
    };

    await supabaseUpsert([row], "haas_shift_history", "machine_id,shift_date,shift_number");
    log(m.name + " | SHIFT SAVED -> " + shiftDate + " " + shiftNames[shiftNum - 1]
      + " | " + sh.parts + " pcs | OEE " + row.oee + "%");
  } catch (e) {
    log(m.name + " | shift save error: " + e.message);
  }
}

async function checkShiftChanges() {
  const curKey = shiftKey();
  for (const m of CONFIG.machines) {
    const prev = prevShiftKeyByMachine[m.id];
    if (prev && prev !== curKey) {
      // Shift just flipped — save the completed shift
      await saveShiftSummary(m, prev);
    }
    prevShiftKeyByMachine[m.id] = curKey;
  }
}

async function pushAllToSupabase() {
  const dayKey  = todayKey();
  const shKey   = shiftKey();
  const curShift = currentShift();
  const rows = CONFIG.machines.map((m) => {
    const rec     = store.machines[m.id];
    const d       = rec.daily[dayKey] || { runSeconds:0, idleSeconds:0, downSeconds:0, parts:0, alarms:0 };
    const sh      = (rec.shifts && rec.shifts[shKey]) || { runSeconds:0, idleSeconds:0, downSeconds:0, parts:0 };
    // Use current SHIFT OEE for live display -- resets fresh every shift
    const oee     = computeShiftOEE(sh, rec, m);
    const dayOee  = computeOEE(rec, dayKey, m);
    const snap = rec.lastSnapshot || {};
    const recent = rec.cycles.slice(-20);
    const avgCycle = recent.length
      ? recent.reduce((s, c) => s + c.seconds, 0) / recent.length : null;

    const alarmActive = alarmIsActive(snap.alarm);
    let status = "offline";
    if (snap.online) {
      if (alarmActive) status = "alarm";
      else if (isRunning(snap.runStatus)) status = "running";
      else status = "idle";
    }

    return {
      machine_id:        m.machineId,
      haas_id:           m.id,
      name:              m.name,
      ip:                m.ip,
      online:            snap.online || false,
      status:            status,
      run_status:        snap.runStatus   || "OFFLINE",
      program:           snap.program     || "-",
      alarm:             snap.alarm       || "-",
      estop:             snap.estop       || "-",
      part_count:        snap.partCount   || 0,
      parts_today:       d.parts,
      parts_this_shift:  sh.parts,
      current_shift:     curShift.name,
      shift_run_seconds: sh.runSeconds,
      avg_cycle_sec:     avgCycle ? Math.round(avgCycle * 10) / 10 : null,
      last_cycle_sec:    snap.lastCycleSec || null,
      this_cycle_sec:    snap.thisCycleSec || null,
      spindle_speed:     snap.spindleSpeed || null,
      feed_override:     snap.feedOverride || null,
      run_seconds:       d.runSeconds,
      idle_seconds:      d.idleSeconds,
      down_seconds:      d.downSeconds,
      // Shift OEE -- resets every shift (what shows on the live dashboard)
      oee:               oee ? Math.round(oee.oee          * 1000) / 10 : 0,
      availability:      oee ? Math.round(oee.availability * 1000) / 10 : 0,
      performance:       oee ? Math.round(oee.performance  * 1000) / 10 : 0,
      quality:           oee ? Math.round(oee.quality      * 1000) / 10 : 100,
      // OEE loss breakdown
      avail_loss:        oee ? oee.availLoss  : 0,
      perf_loss:         oee ? oee.perfLoss   : 0,
      qual_loss:         oee ? oee.qualLoss   : 0,
      down_pct:          oee ? oee.downPct    : 0,
      idle_pct:          oee ? oee.idlePct    : 0,
      setup_pct:         oee ? oee.setupPct   : 0,
      avg_feed_pct:      oee ? oee.avgFeedPct : 100,
      good_parts:        oee ? oee.goodParts  : 0,
      scrap_parts:       sh.scrapParts || 0,
      // Daily OEE -- all shifts combined
      day_oee:           dayOee ? Math.round(dayOee.oee          * 1000) / 10 : 0,
      day_availability:  dayOee ? Math.round(dayOee.availability * 1000) / 10 : 0,
      last_update:       new Date().toISOString(),
    };
  });

  await supabaseUpsert(rows);
  log("Supabase sync OK - " + rows.length + " machines pushed");
}

/* ==========================================================================
   DASHBOARD API
   ========================================================================== */
function machinePayload(rec) {
  const dayKey = todayKey();
  const d = ensureDay(rec, dayKey);
  const mc = CONFIG.machines.find(m => m.id === rec.id) || {};
  const oee = computeOEE(rec, dayKey, mc);
  const recent = rec.cycles.slice(-20);
  const avgCycle = recent.length
    ? recent.reduce((s, c) => s + c.seconds, 0) / recent.length : null;
  return {
    id: rec.id, machineId: rec.machineId, name: rec.name,
    snapshot: rec.lastSnapshot, today: d, oee: oee, avgCycleSec: avgCycle,
    recentEvents: rec.events.slice(-30).reverse(),
    dailyHistory: Object.keys(rec.daily).sort().slice(-14)
      .map((k) => ({ date: k, ...rec.daily[k], oee: computeOEE(rec, k, mc) })),
  };
}

function buildApiPayload() {
  return {
    generatedAt: new Date().toISOString(),
    config: { pollSeconds: CONFIG.pollSeconds, idealCycleSeconds: CONFIG.idealCycleSeconds },
    machines: CONFIG.machines.map((m) => {
      const p = machinePayload(store.machines[m.id]);
      p.ip = m.ip; p.port = m.port;
      return p;
    }),
  };
}

/* ==========================================================================
   WEB SERVER  (local dashboard at http://localhost:8088)
   ========================================================================== */
function startWebServer() {
  const server = http.createServer((req, res) => {
    if (req.url === "/api") {
      res.writeHead(200, { "Content-Type": "application/json",
                           "Access-Control-Allow-Origin": "*" });
      res.end(JSON.stringify(buildApiPayload()));
      return;
    }
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    res.end(DASHBOARD_HTML);
  });
  server.listen(CONFIG.dashboardPort, () => {
    log("Dashboard ready  ->  http://localhost:" + CONFIG.dashboardPort);
    log("Supabase sync:  " + (CONFIG.pushToSupabase ? "ENABLED" : "disabled"));
  });
}

/* ==========================================================================
   DASHBOARD HTML  (local view)
   ========================================================================== */
const DASHBOARD_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>NIDC Haas Monitor</title>
<style>
  :root{
    --bg:#0e1116; --panel:#161b22; --panel2:#1c232d; --line:#2a3340;
    --txt:#e6edf3; --dim:#8b949e; --accent:#ff7a18;
    --green:#3fb950; --amber:#d29922; --red:#f85149; --blue:#388bfd;
  }
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:var(--bg);color:var(--txt);
    font-family:"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
    padding:20px;line-height:1.5}
  .head{display:flex;align-items:baseline;gap:14px;flex-wrap:wrap;margin-bottom:4px}
  .head h1{font-size:21px;font-weight:700;letter-spacing:.3px}
  .head .meta{color:var(--dim);font-size:12px}
  .sub{color:var(--dim);font-size:12px;margin:2px 0 18px}
  .sync-badge{display:inline-block;padding:2px 10px;border-radius:10px;font-size:11px;font-weight:700;background:rgba(63,185,80,.15);color:var(--green);margin-left:8px}
  .summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));
    gap:12px;margin-bottom:20px}
  .sumcard{background:var(--panel);border:1px solid var(--line);
    border-radius:10px;padding:14px}
  .sumcard .l{font-size:10px;text-transform:uppercase;letter-spacing:1px;
    color:var(--dim);font-weight:600}
  .sumcard .v{font-size:30px;font-weight:700;margin-top:4px}
  .tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));
    gap:14px;margin-bottom:8px}
  .tile{background:var(--panel);border:1px solid var(--line);
    border-radius:12px;padding:16px;border-left:5px solid #484f58}
  .tile.run{border-left-color:var(--green)}
  .tile.idle{border-left-color:var(--amber)}
  .tile.down{border-left-color:var(--red)}
  .tile.off{border-left-color:#484f58}
  .tile .top{display:flex;justify-content:space-between;align-items:center;
    margin-bottom:12px}
  .tile h3{font-size:16px;font-weight:700}
  .badge{padding:3px 10px;border-radius:12px;font-size:11px;font-weight:700;
    text-transform:uppercase;letter-spacing:.5px}
  .badge.run{background:rgba(63,185,80,.18);color:var(--green)}
  .badge.idle{background:rgba(210,153,34,.18);color:var(--amber)}
  .badge.down{background:rgba(248,81,73,.18);color:var(--red)}
  .badge.off{background:rgba(139,148,158,.18);color:var(--dim)}
  .pulse{animation:pulse 2s infinite}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
  .row{display:flex;justify-content:space-between;font-size:13px;
    padding:4px 0;border-bottom:1px solid var(--line)}
  .row .k{color:var(--dim)}
  .row .v{font-weight:600;font-family:Consolas,monospace}
  .stats{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:12px 0}
  .stat{background:var(--panel2);border-radius:8px;padding:10px 6px;text-align:center}
  .stat .v{font-size:22px;font-weight:700}
  .stat .l{font-size:9px;text-transform:uppercase;color:var(--dim);
    letter-spacing:.5px;margin-top:2px}
  .oee{margin-top:10px}
  .oee .label{display:flex;justify-content:space-between;font-size:11px;
    color:var(--dim);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px}
  .oee .num{color:var(--accent);font-weight:700;font-size:13px}
  .bar{height:8px;background:var(--panel2);border-radius:4px;overflow:hidden}
  .bar>div{height:100%;border-radius:4px;transition:width .4s ease}
  .events{margin-top:12px}
  .events .eh{font-size:10px;text-transform:uppercase;letter-spacing:1px;
    color:var(--dim);font-weight:600;margin-bottom:6px}
  .ev{display:flex;gap:8px;font-size:12px;padding:3px 0}
  .ev .t{color:var(--dim);font-family:Consolas,monospace;flex-shrink:0}
  .tag{display:inline-block;padding:1px 7px;border-radius:9px;font-size:10px;font-weight:600;flex-shrink:0}
  .tag.part{background:rgba(63,185,80,.15);color:var(--green)}
  .tag.alarm{background:rgba(248,81,73,.15);color:var(--red)}
  .tag.state{background:rgba(56,139,253,.15);color:var(--blue)}
  .tag.prog{background:rgba(210,153,34,.15);color:var(--amber)}
  .tag.off{background:rgba(248,81,73,.15);color:var(--red)}
  .tag.on{background:rgba(63,185,80,.15);color:var(--green)}
  .foot{color:var(--dim);font-size:11px;margin-top:20px;text-align:center}
</style>
</head>
<body>
  <div class="head">
    <h1>NIDC Haas Monitor</h1>
    <span class="meta" id="meta"></span>
    <span class="sync-badge">🟢 LIVE → Supabase</span>
  </div>
  <div class="sub" id="updated">Connecting...</div>
  <div class="summary" id="summary"></div>
  <div class="tiles" id="tiles"></div>
  <div class="foot">NIDC Haas Bridge v2.1 — M453 M432 M439 M440 — syncing to Supabase every 5s</div>
<script>
function hms(sec){sec=Math.round(sec||0);var h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=sec%60;if(h>0)return h+"h "+m+"m";if(m>0)return m+"m "+s+"s";return s+"s";}
function pct(x){return Math.round((x||0)*100)+"%";}
function esc(t){var d=document.createElement("div");d.textContent=t==null?"":String(t);return d.innerHTML;}
function tagClass(t){if(t==="PART_COMPLETE")return"part";if(t==="ALARM")return"alarm";if(t==="ALARM_CLEARED"||t==="ONLINE")return"on";if(t==="STATE_CHANGE")return"state";if(t==="PROGRAM_CHANGE")return"prog";if(t==="OFFLINE")return"off";return"state";}
function stateOf(s){if(!s||!s.online)return"off";var a=s.alarm&&s.alarm.toUpperCase()!=="NO ACTIVE ALARMS"&&s.alarm.toUpperCase()!=="UNKNOWN"&&s.alarm!=="-";if(a)return"down";if(s.runStatus==="EXECUTING"||s.runStatus==="ACTIVE")return"run";return"idle";}
function stateLabel(st){return st==="run"?"Running":st==="idle"?"Idle":st==="down"?"Alarm":"Offline";}
async function refresh(){
  try{
    var r=await fetch("/api");var d=await r.json();
    document.getElementById("meta").textContent=d.machines.length+" machines (M453 M432 M439 M440) - polling every "+d.config.pollSeconds+"s";
    document.getElementById("updated").textContent="Last update: "+new Date(d.generatedAt).toLocaleString();
    var running=0,idle=0,down=0,off=0,partsTotal=0,oeeSum=0,oeeCount=0;
    d.machines.forEach(function(m){var st=stateOf(m.snapshot);if(st==="run")running++;else if(st==="idle")idle++;else if(st==="down")down++;else off++;if(m.today)partsTotal+=m.today.parts;if(m.oee){oeeSum+=m.oee.oee;oeeCount++;}});
    var avgOee=oeeCount?oeeSum/oeeCount:0;
    document.getElementById("summary").innerHTML=sumCard("Running",running,"var(--green)")+sumCard("Idle",idle,"var(--amber)")+sumCard("Alarm / Off",down+off,"var(--red)")+sumCard("Parts Today",partsTotal,"var(--txt)")+sumCard("Avg OEE",pct(avgOee),"var(--accent)");
    document.getElementById("tiles").innerHTML=d.machines.map(tileHtml).join("");
  }catch(err){document.getElementById("updated").textContent="Cannot reach the bridge - is it still running?";}
}
function sumCard(label,val,color){return '<div class="sumcard"><div class="l">'+label+'</div><div class="v" style="color:'+color+'">'+val+'</div></div>';}
function tileHtml(m){
  var s=m.snapshot;var st=stateOf(s);
  var badge='<span class="badge '+st+(st==="run"?" pulse":"")+'">'+stateLabel(st)+'</span>';
  var rows="";
  if(s){rows+=infoRow("Machine ID",m.machineId||m.id);rows+=infoRow("Program",s.program||"-");rows+=infoRow("Run status",s.runStatus||"-");rows+=infoRow("Alarm",s.alarm&&s.alarm!=="-"?s.alarm:"-");rows+=infoRow("Spindle",s.spindleSpeed!=null?s.spindleSpeed+" RPM":"-");rows+=infoRow("Feed override",s.feedOverride!=null?s.feedOverride+"%":"-");rows+=infoRow("Address",m.ip+":"+m.port);}
  var t=m.today||{parts:0,runSeconds:0,idleSeconds:0,downSeconds:0};
  var stats='<div class="stats">'+statBox(t.parts,"Parts Today")+statBox(m.avgCycleSec?Math.round(m.avgCycleSec)+"s":"--","Avg Cycle")+statBox(hms(t.runSeconds),"Run Time")+'</div>';
  var oeeBlock="";
  if(m.oee){var col=m.oee.oee>=0.6?"var(--green)":m.oee.oee>=0.4?"var(--amber)":"var(--red)";oeeBlock='<div class="oee"><div class="label"><span>OEE Today</span><span class="num">'+pct(m.oee.oee)+'</span></div><div class="bar"><div style="width:'+pct(m.oee.oee)+';background:'+col+'"></div></div><div class="label" style="margin-top:6px"><span>A '+pct(m.oee.availability)+'</span><span>P '+pct(m.oee.performance)+'</span><span>Q '+pct(m.oee.quality)+'</span></div></div>';}
  var evs="";
  if(m.recentEvents&&m.recentEvents.length){evs=m.recentEvents.slice(0,5).map(function(e){return '<div class="ev"><span class="t">'+new Date(e.time).toLocaleTimeString()+'</span><span class="tag '+tagClass(e.type)+'">'+esc(e.type)+'</span><span>'+esc(e.detail||"")+'</span></div>';}).join("");}else{evs='<div class="ev"><span class="t">--</span><span>No events yet</span></div>';}
  return '<div class="tile '+st+'"><div class="top"><h3>'+esc(m.name)+'</h3>'+badge+'</div>'+rows+stats+oeeBlock+'<div class="events"><div class="eh">Recent Activity</div>'+evs+'</div></div>';
}
function infoRow(k,v){return '<div class="row"><span class="k">'+k+'</span><span class="v">'+esc(v)+'</span></div>';}
function statBox(v,l){return '<div class="stat"><div class="v">'+v+'</div><div class="l">'+l+'</div></div>';}
refresh();setInterval(refresh,5000);
</script>
</body>
</html>`;

/* ==========================================================================
   STARTUP
   ========================================================================== */
function main() {
  console.log("");
  console.log("==================================================");
  console.log("  NIDC HAAS BRIDGE v2.1  -  multi-machine + cloud");
  console.log("==================================================");
  CONFIG.machines.forEach((m) =>
    log("  " + m.name + " (" + m.machineId + ")  ->  http://" + m.ip + ":" + m.port + "/current"));
  log("Poll: every " + CONFIG.pollSeconds + " seconds");
  log("Supabase sync: " + (CONFIG.pushToSupabase ? "ENABLED" : "disabled"));
  console.log("");

  loadStore();
  startWebServer();

  pollAll().catch((e) => log("Poll error: " + e.message));
  setInterval(() => {
    pollAll().catch((e) => log("Poll error: " + e.message));
  }, CONFIG.pollSeconds * 1000);
}

main();
