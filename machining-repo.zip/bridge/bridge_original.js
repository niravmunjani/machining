/* ==========================================================================
   NIDC HAAS BRIDGE  v2  -  Multi-machine monitor
   --------------------------------------------------------------------------
   Monitors all 5 Haas machines at once. Reads live MTConnect data, tracks
   parts and run state, calculates OEE, keeps history, and shows everything
   on one dashboard. No database, no cloud - runs on one office PC.

   How to run:
     1. Install Node.js   (https://nodejs.org  - get the LTS version)
     2. Double-click START-HERE.bat
     3. Open a browser to  http://localhost:8088

   To change machine IPs or settings, edit the CONFIG block right below.
   ========================================================================== */

const http = require("http");
const fs = require("fs");
const path = require("path");
const { XMLParser } = require("fast-xml-parser");

/* ==========================================================================
   CONFIG  -  the only part you should ever need to edit
   ========================================================================== */
const CONFIG = {
  // --- Your Haas machines --------------------------------------------------
  // One line per machine. "id" must be unique (used internally).
  // If a machine's IP changes, edit it here. If the MTConnect port is
  // different, change "port". HAAS 5 is a placeholder - fix its IP.
  machines: [
    { id: "haas1", name: "HAAS 1 (VF-3SS)", ip: "192.168.1.17", port: 8082 },
    { id: "haas2", name: "HAAS 2",          ip: "192.168.1.18", port: 8082 },
    { id: "haas3", name: "HAAS 3",          ip: "192.168.1.20", port: 8082 },
    { id: "haas4", name: "HAAS 4",          ip: "192.168.1.21", port: 8082 },
    { id: "haas5", name: "HAAS 5",          ip: "192.168.1.19", port: 8082 },
  ],

  // --- How often to check each machine ------------------------------------
  pollSeconds: 5,

  // --- Dashboard -----------------------------------------------------------
  dashboardPort: 8088,         // open http://localhost:8088 in a browser

  // --- OEE settings (applied to every machine) ----------------------------
  // "Ideal" cycle time = fastest a good part can be made, in seconds.
  idealCycleSeconds: 60,
  // Planned production minutes per day. 1380 = two shifts (23h).
  plannedMinutesPerDay: 1380,

  // --- Data storage --------------------------------------------------------
  dataFile: path.join(__dirname, "haas-data.json"),
  maxEventsPerMachine: 3000,
};

/* ==========================================================================
   DATA STORE  -  a simple JSON file acts as our "database"
   One record per machine, keyed by machine id.
   ========================================================================== */
let store = { machines: {} };

function blankMachine(m) {
  return {
    id: m.id,
    name: m.name,
    events: [],          // {time, type, detail}
    cycles: [],          // {time, seconds}
    daily: {},           // per-day totals keyed by YYYY-MM-DD
    lastSnapshot: null,
  };
}

function loadStore() {
  try {
    if (fs.existsSync(CONFIG.dataFile)) {
      store = JSON.parse(fs.readFileSync(CONFIG.dataFile, "utf8"));
      log("Loaded existing data file.");
    } else {
      log("No data file yet - starting fresh.");
    }
  } catch (e) {
    log("WARNING: could not read data file, starting fresh. " + e.message);
    store = { machines: {} };
  }
  // Make sure every configured machine has a record.
  for (const m of CONFIG.machines) {
    if (!store.machines[m.id]) store.machines[m.id] = blankMachine(m);
    else store.machines[m.id].name = m.name; // keep name in sync with config
  }
}

let saveTimer = null;
function saveStore() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      for (const id of Object.keys(store.machines)) {
        const r = store.machines[id];
        if (r.events.length > CONFIG.maxEventsPerMachine)
          r.events = r.events.slice(-CONFIG.maxEventsPerMachine);
        if (r.cycles.length > CONFIG.maxEventsPerMachine)
          r.cycles = r.cycles.slice(-CONFIG.maxEventsPerMachine);
      }
      fs.writeFileSync(CONFIG.dataFile, JSON.stringify(store, null, 2));
    } catch (e) {
      log("WARNING: could not save data file. " + e.message);
    }
  }, 2000);
}

/* ==========================================================================
   LOGGING
   ========================================================================== */
function log(msg) {
  console.log("[" + new Date().toLocaleTimeString() + "] " + msg);
}

/* ==========================================================================
   XML PARSING  -  pull values out of the MTConnect feed
   ========================================================================== */
const xml = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: "@_" });

function findAll(node, tagName, results) {
  if (node == null || typeof node !== "object") return results;
  for (const key of Object.keys(node)) {
    if (key === tagName) {
      const v = node[key];
      if (Array.isArray(v)) results.push(...v);
      else results.push(v);
    }
    const child = node[key];
    if (Array.isArray(child)) child.forEach((c) => findAll(c, tagName, results));
    else if (typeof child === "object") findAll(child, tagName, results);
  }
  return results;
}

function valueByName(parsed, tagName, nameAttr) {
  for (const el of findAll(parsed, tagName, [])) {
    if (el && el["@_name"] === nameAttr)
      return el["#text"] !== undefined ? el["#text"] : el;
  }
  return null;
}

function readSnapshot(parsed) {
  const runStatus = valueByName(parsed, "Execution", "RunStatus");
  const mode = valueByName(parsed, "ControllerMode", "Mode");
  const program = valueByName(parsed, "Program", "Program");
  const alarm = valueByName(parsed, "Message", "ActiveAlarms");
  const m30 = valueByName(parsed, "Message", "M30Counter1");
  const lastCycle = valueByName(parsed, "AccumulatedTime", "LastCycle");
  const thisCycle = valueByName(parsed, "AccumulatedTime", "ThisCycle");
  const spindleSpeed = valueByName(parsed, "SpindleSpeed", "SpindleSpeed");
  const availability = valueByName(parsed, "Availability", "Availability");
  const estop = valueByName(parsed, "EmergencyStop", "EmergencyStop");
  const feedOvr = valueByName(parsed, "PathFeedrate", "FeedrateOverride");

  return {
    time: new Date().toISOString(),
    online: true,
    runStatus: runStatus != null ? String(runStatus) : "UNKNOWN",
    mode: mode != null ? String(mode) : "UNKNOWN",
    program: program != null ? String(program) : "-",
    alarm: alarm != null ? String(alarm) : "UNKNOWN",
    partCount: m30 != null ? Number(m30) : null,
    lastCycleSec: lastCycle != null ? Number(lastCycle) : null,
    thisCycleSec: thisCycle != null ? Number(thisCycle) : null,
    spindleSpeed: spindleSpeed != null ? Number(spindleSpeed) : null,
    availability: availability != null ? String(availability) : "UNKNOWN",
    estop: estop != null ? String(estop) : "UNKNOWN",
    feedOverride: feedOvr != null ? Number(feedOvr) : null,
  };
}

/* ==========================================================================
   HELPERS
   ========================================================================== */
function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function ensureDay(rec, key) {
  if (!rec.daily[key]) {
    rec.daily[key] = {
      runSeconds: 0, idleSeconds: 0, downSeconds: 0, parts: 0, alarms: 0,
    };
  }
  return rec.daily[key];
}

function addEvent(rec, type, detail) {
  rec.events.push({ time: new Date().toISOString(), type, detail });
  log(rec.name + " | " + type + (detail ? " - " + detail : ""));
}

function isRunning(status) {
  const s = (status || "").toUpperCase();
  return s === "EXECUTING" || s === "ACTIVE";
}

function alarmIsActive(alarm) {
  if (!alarm) return false;
  const a = alarm.toUpperCase();
  return a !== "NO ACTIVE ALARMS" && a !== "UNKNOWN" && a !== "-";
}

/* ==========================================================================
   THE POLLER  -  one machine at a time
   ========================================================================== */
// Per-machine memory of the previous reading, so we can detect changes.
const prevByMachine = {};

function fetchFeed(m) {
  return new Promise((resolve, reject) => {
    const url = "http://" + m.ip + ":" + m.port + "/current";
    const req = http.get(url, { timeout: 8000 }, (res) => {
      let body = "";
      res.on("data", (c) => (body += c));
      res.on("end", () => resolve(body));
    });
    req.on("timeout", () => { req.destroy(); reject(new Error("timed out")); });
    req.on("error", (e) => reject(e));
  });
}

async function pollMachine(m) {
  const rec = store.machines[m.id];
  const day = ensureDay(rec, todayKey());
  const prev = prevByMachine[m.id] || {};
  let snap;

  try {
    const body = await fetchFeed(m);
    const parsed = xml.parse(body);
    snap = readSnapshot(parsed);
  } catch (e) {
    // Machine unreachable.
    snap = {
      time: new Date().toISOString(), online: false, runStatus: "OFFLINE",
      mode: "-", program: "-", alarm: "-", partCount: prev.partCount,
      lastCycleSec: null, thisCycleSec: null, spindleSpeed: null,
      availability: "UNAVAILABLE", estop: "-", feedOverride: null,
    };
    if (prev.online !== false) addEvent(rec, "OFFLINE", "Unreachable: " + e.message);
    day.downSeconds += CONFIG.pollSeconds;
    prevByMachine[m.id] = { ...prev, online: false };
    rec.lastSnapshot = snap;
    return;
  }

  if (prev.online === false) addEvent(rec, "ONLINE", "Reachable again");

  // --- Time buckets for OEE -----------------------------------------------
  const alarmActive = alarmIsActive(snap.alarm);
  if (alarmActive) day.downSeconds += CONFIG.pollSeconds;
  else if (isRunning(snap.runStatus)) day.runSeconds += CONFIG.pollSeconds;
  else day.idleSeconds += CONFIG.pollSeconds;

  // --- New finished part ---------------------------------------------------
  if (prev.partCount != null && snap.partCount != null &&
      snap.partCount > prev.partCount) {
    const made = snap.partCount - prev.partCount;
    day.parts += made;
    const cyc = snap.lastCycleSec || snap.thisCycleSec || null;
    if (cyc) rec.cycles.push({ time: snap.time, seconds: cyc });
    addEvent(rec, "PART_COMPLETE",
      made + " part(s), cycle " + (cyc ? cyc + "s" : "n/a"));
  }

  // --- State / alarm / program changes ------------------------------------
  if (prev.runStatus != null && snap.runStatus !== prev.runStatus)
    addEvent(rec, "STATE_CHANGE", prev.runStatus + " -> " + snap.runStatus);

  if (prev.alarm != null && snap.alarm !== prev.alarm) {
    if (alarmActive) { day.alarms += 1; addEvent(rec, "ALARM", snap.alarm); }
    else addEvent(rec, "ALARM_CLEARED", "Alarms cleared");
  }

  if (prev.program != null && snap.program !== prev.program)
    addEvent(rec, "PROGRAM_CHANGE", prev.program + " -> " + snap.program);

  prevByMachine[m.id] = {
    online: true, partCount: snap.partCount, runStatus: snap.runStatus,
    alarm: snap.alarm, program: snap.program,
  };
  rec.lastSnapshot = snap;
}

async function pollAll() {
  // Poll every machine; one failure must not stop the others.
  await Promise.all(
    CONFIG.machines.map((m) =>
      pollMachine(m).catch((e) => log(m.name + " poll error: " + e.message))
    )
  );
  saveStore();
}

/* ==========================================================================
   OEE CALCULATION
   ========================================================================== */
function computeOEE(rec, dayKey) {
  const d = rec.daily[dayKey];
  if (!d) return null;
  const plannedSec = CONFIG.plannedMinutesPerDay * 60;
  const availability = plannedSec > 0 ? d.runSeconds / plannedSec : 0;
  const idealTotal = CONFIG.idealCycleSeconds * d.parts;
  const performance = d.runSeconds > 0 ? idealTotal / d.runSeconds : 0;
  const quality = 1.0; // no scrap data yet
  const oee = availability * performance * quality;
  return {
    availability: clamp(availability), performance: clamp(performance),
    quality: clamp(quality), oee: clamp(oee),
  };
}
function clamp(x) {
  if (isNaN(x) || x < 0) return 0;
  if (x > 1) return 1;
  return x;
}

/* ==========================================================================
   DASHBOARD API PAYLOAD
   ========================================================================== */
function machinePayload(rec) {
  const dayKey = todayKey();
  const d = ensureDay(rec, dayKey);
  const oee = computeOEE(rec, dayKey);
  const recent = rec.cycles.slice(-20);
  const avgCycle = recent.length
    ? recent.reduce((s, c) => s + c.seconds, 0) / recent.length : null;
  return {
    id: rec.id, name: rec.name,
    snapshot: rec.lastSnapshot, today: d, oee: oee, avgCycleSec: avgCycle,
    recentEvents: rec.events.slice(-30).reverse(),
    dailyHistory: Object.keys(rec.daily).sort().slice(-14)
      .map((k) => ({ date: k, ...rec.daily[k], oee: computeOEE(rec, k) })),
  };
}

function buildApiPayload() {
  return {
    generatedAt: new Date().toISOString(),
    config: { pollSeconds: CONFIG.pollSeconds,
              idealCycleSeconds: CONFIG.idealCycleSeconds },
    machines: CONFIG.machines.map((m) => {
      const p = machinePayload(store.machines[m.id]);
      p.ip = m.ip; p.port = m.port;
      return p;
    }),
  };
}

/* ==========================================================================
   WEB SERVER
   ========================================================================== */
function startWebServer() {
  const server = http.createServer((req, res) => {
    if (req.url === "/api") {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify(buildApiPayload()));
      return;
    }
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    res.end(DASHBOARD_HTML);
  });
  server.listen(CONFIG.dashboardPort, () => {
    log("Dashboard ready  ->  http://localhost:" + CONFIG.dashboardPort);
  });
}

/* ==========================================================================
   DASHBOARD HTML
   ========================================================================== */
const DASHBOARD_HTML = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>NIDC Haas Monitor</title>
<style>
  :root{
    --bg:#0e1116; --panel:#161b22; --panel2:#1c232d; --line:#2a3340;
    --txt:#e6edf3; --dim:#8b949e; --accent:#ff7a18;
    --green:#3fb950; --amber:#d29922; --red:#f85149; --blue:#388bfd;
  }
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:var(--bg);color:var(--txt);
    font-family:"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
    padding:20px;line-height:1.5}
  .head{display:flex;align-items:baseline;gap:14px;flex-wrap:wrap}
  .head h1{font-size:21px;font-weight:700;letter-spacing:.3px}
  .head .meta{color:var(--dim);font-size:12px}
  .sub{color:var(--dim);font-size:12px;margin:2px 0 18px}

  /* ---- plant summary strip ---- */
  .summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));
    gap:12px;margin-bottom:20px}
  .sumcard{background:var(--panel);border:1px solid var(--line);
    border-radius:10px;padding:14px}
  .sumcard .l{font-size:10px;text-transform:uppercase;letter-spacing:1px;
    color:var(--dim);font-weight:600}
  .sumcard .v{font-size:30px;font-weight:700;margin-top:4px}

  /* ---- machine tiles ---- */
  .tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));
    gap:14px;margin-bottom:8px}
  .tile{background:var(--panel);border:1px solid var(--line);
    border-radius:12px;padding:16px;border-left:5px solid #484f58}
  .tile.run{border-left-color:var(--green)}
  .tile.idle{border-left-color:var(--amber)}
  .tile.down{border-left-color:var(--red)}
  .tile.off{border-left-color:#484f58}
  .tile .top{display:flex;justify-content:space-between;align-items:center;
    margin-bottom:12px}
  .tile h3{font-size:16px;font-weight:700}
  .badge{padding:3px 10px;border-radius:12px;font-size:11px;font-weight:700;
    text-transform:uppercase;letter-spacing:.5px}
  .badge.run{background:rgba(63,185,80,.18);color:var(--green)}
  .badge.idle{background:rgba(210,153,34,.18);color:var(--amber)}
  .badge.down{background:rgba(248,81,73,.18);color:var(--red)}
  .badge.off{background:rgba(139,148,158,.18);color:var(--dim)}
  .pulse{animation:pulse 2s infinite}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
  .row{display:flex;justify-content:space-between;font-size:13px;
    padding:4px 0;border-bottom:1px solid var(--line)}
  .row .k{color:var(--dim)}
  .row .v{font-weight:600;font-family:Consolas,monospace}
  .stats{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:12px 0}
  .stat{background:var(--panel2);border-radius:8px;padding:10px 6px;text-align:center}
  .stat .v{font-size:22px;font-weight:700}
  .stat .l{font-size:9px;text-transform:uppercase;color:var(--dim);
    letter-spacing:.5px;margin-top:2px}
  .oee{margin-top:10px}
  .oee .label{display:flex;justify-content:space-between;font-size:11px;
    color:var(--dim);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px}
  .oee .num{color:var(--accent);font-weight:700;font-size:13px}
  .bar{height:8px;background:var(--panel2);border-radius:4px;overflow:hidden}
  .bar>div{height:100%;border-radius:4px;transition:width .4s ease}
  .events{margin-top:12px}
  .events .eh{font-size:10px;text-transform:uppercase;letter-spacing:1px;
    color:var(--dim);font-weight:600;margin-bottom:6px}
  .ev{display:flex;gap:8px;font-size:12px;padding:3px 0}
  .ev .t{color:var(--dim);font-family:Consolas,monospace;flex-shrink:0}
  .tag{display:inline-block;padding:1px 7px;border-radius:9px;font-size:10px;
    font-weight:600;flex-shrink:0}
  .tag.part{background:rgba(63,185,80,.15);color:var(--green)}
  .tag.alarm{background:rgba(248,81,73,.15);color:var(--red)}
  .tag.state{background:rgba(56,139,253,.15);color:var(--blue)}
  .tag.prog{background:rgba(210,153,34,.15);color:var(--amber)}
  .tag.off{background:rgba(248,81,73,.15);color:var(--red)}
  .tag.on{background:rgba(63,185,80,.15);color:var(--green)}
  .foot{color:var(--dim);font-size:11px;margin-top:20px;text-align:center}
</style>
</head>
<body>
  <div class="head">
    <h1>NIDC Haas Monitor</h1>
    <span class="meta" id="meta"></span>
  </div>
  <div class="sub" id="updated">Connecting...</div>

  <div class="summary" id="summary"></div>
  <div class="tiles" id="tiles"></div>

  <div class="foot">
    NIDC Haas Bridge v2 - monitoring all machines -
    history saved locally to haas-data.json
  </div>

<script>
function hms(sec){
  sec=Math.round(sec||0);
  var h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=sec%60;
  if(h>0)return h+"h "+m+"m";
  if(m>0)return m+"m "+s+"s";
  return s+"s";
}
function pct(x){return Math.round((x||0)*100)+"%";}
function esc(t){var d=document.createElement("div");d.textContent=t==null?"":String(t);return d.innerHTML;}
function tagClass(t){
  if(t==="PART_COMPLETE")return"part";
  if(t==="ALARM")return"alarm";
  if(t==="ALARM_CLEARED"||t==="ONLINE")return"on";
  if(t==="STATE_CHANGE")return"state";
  if(t==="PROGRAM_CHANGE")return"prog";
  if(t==="OFFLINE")return"off";
  return"state";
}
function stateOf(s){
  if(!s||!s.online)return"off";
  var a=s.alarm&&s.alarm.toUpperCase()!=="NO ACTIVE ALARMS"
        &&s.alarm.toUpperCase()!=="UNKNOWN"&&s.alarm!=="-";
  if(a)return"down";
  if(s.runStatus==="EXECUTING"||s.runStatus==="ACTIVE")return"run";
  return"idle";
}
function stateLabel(st){
  return st==="run"?"Running":st==="idle"?"Idle":
         st==="down"?"Alarm":"Offline";
}

async function refresh(){
  try{
    var r=await fetch("/api");
    var d=await r.json();

    document.getElementById("meta").textContent=
      d.machines.length+" machines - polling every "+d.config.pollSeconds+"s";
    document.getElementById("updated").textContent=
      "Last update: "+new Date(d.generatedAt).toLocaleString();

    // ---- plant summary ----
    var running=0,idle=0,down=0,off=0,partsTotal=0,oeeSum=0,oeeCount=0;
    d.machines.forEach(function(m){
      var st=stateOf(m.snapshot);
      if(st==="run")running++;else if(st==="idle")idle++;
      else if(st==="down")down++;else off++;
      if(m.today)partsTotal+=m.today.parts;
      if(m.oee){oeeSum+=m.oee.oee;oeeCount++;}
    });
    var avgOee=oeeCount?oeeSum/oeeCount:0;
    document.getElementById("summary").innerHTML=
      sumCard("Running",running,"var(--green)")+
      sumCard("Idle",idle,"var(--amber)")+
      sumCard("Alarm / Off",down+off,"var(--red)")+
      sumCard("Parts Today",partsTotal,"var(--txt)")+
      sumCard("Avg OEE",pct(avgOee),"var(--accent)");

    // ---- machine tiles ----
    document.getElementById("tiles").innerHTML=
      d.machines.map(tileHtml).join("");
  }catch(err){
    document.getElementById("updated").textContent=
      "Cannot reach the bridge service - is it still running?";
  }
}

function sumCard(label,val,color){
  return '<div class="sumcard"><div class="l">'+label+'</div>'+
         '<div class="v" style="color:'+color+'">'+val+'</div></div>';
}

function tileHtml(m){
  var s=m.snapshot;
  var st=stateOf(s);
  var cls="tile "+st;
  var badge='<span class="badge '+st+(st==="run"?" pulse":"")+'">'+
            stateLabel(st)+'</span>';

  var rows="";
  if(s){
    rows+=infoRow("Program",s.program||"-");
    rows+=infoRow("Run status",s.runStatus||"-");
    var alarmTxt = (s.alarm&&s.alarm!=="-")?s.alarm:"-";
    rows+=infoRow("Alarm",alarmTxt);
    rows+=infoRow("Address",m.ip+":"+m.port);
  }else{
    rows+=infoRow("Status","No reading yet");
    rows+=infoRow("Address",m.ip+":"+m.port);
  }

  var t=m.today||{parts:0,runSeconds:0,idleSeconds:0,downSeconds:0};
  var stats=
    '<div class="stats">'+
      statBox(t.parts,"Parts Today")+
      statBox(m.avgCycleSec?Math.round(m.avgCycleSec)+"s":"--","Avg Cycle")+
      statBox(hms(t.runSeconds),"Run Time")+
    '</div>';

  var oeeBlock="";
  if(m.oee){
    var col=m.oee.oee>=0.6?"var(--green)":
            m.oee.oee>=0.4?"var(--amber)":"var(--red)";
    oeeBlock=
      '<div class="oee">'+
        '<div class="label"><span>OEE Today</span>'+
        '<span class="num">'+pct(m.oee.oee)+'</span></div>'+
        '<div class="bar"><div style="width:'+pct(m.oee.oee)+
        ';background:'+col+'"></div></div>'+
        '<div class="label" style="margin-top:6px">'+
        '<span>A '+pct(m.oee.availability)+'</span>'+
        '<span>P '+pct(m.oee.performance)+'</span>'+
        '<span>Q '+pct(m.oee.quality)+'</span></div>'+
      '</div>';
  }

  var evs="";
  if(m.recentEvents&&m.recentEvents.length){
    evs=m.recentEvents.slice(0,5).map(function(e){
      return '<div class="ev"><span class="t">'+
        new Date(e.time).toLocaleTimeString()+'</span>'+
        '<span class="tag '+tagClass(e.type)+'">'+esc(e.type)+'</span>'+
        '<span>'+esc(e.detail||"")+'</span></div>';
    }).join("");
  }else{
    evs='<div class="ev"><span class="t">--</span><span>No events yet</span></div>';
  }
  var events='<div class="events"><div class="eh">Recent Activity</div>'+evs+'</div>';

  return '<div class="'+cls+'">'+
           '<div class="top"><h3>'+esc(m.name)+'</h3>'+badge+'</div>'+
           rows+stats+oeeBlock+events+
         '</div>';
}
function infoRow(k,v){
  return '<div class="row"><span class="k">'+k+
         '</span><span class="v">'+esc(v)+'</span></div>';
}
function statBox(v,l){
  return '<div class="stat"><div class="v">'+v+
         '</div><div class="l">'+l+'</div></div>';
}

refresh();
setInterval(refresh,5000);
</script>
</body>
</html>`;

/* ==========================================================================
   STARTUP
   ========================================================================== */
function main() {
  console.log("");
  console.log("==================================================");
  console.log("  NIDC HAAS BRIDGE v2  -  multi-machine monitor");
  console.log("==================================================");
  CONFIG.machines.forEach((m) =>
    log("  " + m.name + "  ->  http://" + m.ip + ":" + m.port + "/current"));
  log("Poll: every " + CONFIG.pollSeconds + " seconds");
  console.log("");

  loadStore();
  startWebServer();

  pollAll().catch((e) => log("Poll error: " + e.message));
  setInterval(() => {
    pollAll().catch((e) => log("Poll error: " + e.message));
  }, CONFIG.pollSeconds * 1000);
}

main();
