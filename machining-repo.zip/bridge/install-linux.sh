#!/usr/bin/env bash
# NIDC Haas Bridge - install as a service on any Linux box (incl. Raspberry Pi)
# Usage:  sudo bash install-linux.sh
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SVC=/etc/systemd/system/nidc-bridge.service

echo "NIDC Haas Bridge - Linux install"
echo "folder: $DIR"
echo

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js not found. Installing..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi
echo "node: $(node --version)"

if [ ! -f "$DIR/.env" ]; then
  cp "$DIR/.env.example" "$DIR/.env"
  echo
  echo ">> Created .env  -  EDIT IT NOW with your machine IPs, then re-run."
  echo "   nano $DIR/.env"
  exit 0
fi

echo "installing dependencies..."
cd "$DIR" && npm install --omit=dev

RUN_AS="${SUDO_USER:-root}"
cat > "$SVC" <<EOF
[Unit]
Description=NIDC Haas Bridge
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$RUN_AS
WorkingDirectory=$DIR
ExecStart=$(command -v node) $DIR/bridge.js
Restart=always
RestartSec=15
StandardOutput=append:$DIR/bridge.log
StandardError=append:$DIR/bridge.log

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable nidc-bridge
systemctl restart nidc-bridge
sleep 2

echo
echo "================================================"
systemctl --no-pager status nidc-bridge | head -12
echo "================================================"
echo
echo "Done. It now starts on boot and restarts if it crashes."
echo
echo "  see logs:   journalctl -u nidc-bridge -f"
echo "  stop:       sudo systemctl stop nidc-bridge"
echo "  dashboard:  http://$(hostname -I | awk '{print $1}'):8088"
