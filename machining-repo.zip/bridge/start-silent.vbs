' NIDC Haas Bridge - Silent launcher (no black window)
' Windows runs this automatically at startup.
' Calls RUN-FOREVER.bat so the bridge restarts itself if it ever crashes.
Dim objShell, objFSO, strDir
Set objShell = CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")
strDir = objFSO.GetParentFolderName(WScript.ScriptFullName)
objShell.CurrentDirectory = strDir
objShell.Run """" & strDir & "\RUN-FOREVER.bat""", 0, False
Set objShell = Nothing
Set objFSO = Nothing
