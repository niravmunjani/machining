/* =======================================================================
   NIDC - Supabase push test
   Tests ONLY the cloud connection, nothing to do with the machines.
   Run:  node test-push.js
   ======================================================================= */
const https = require("https");

const URL_BASE = "https://rjklrzzpwrapxdahgidz.supabase.co";
const KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJqa2xyenpwd3JhcHhkYWhnaWR6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM1MTgyMDEsImV4cCI6MjA4OTA5NDIwMX0.gl3fLz-AD4Xvrub9WRAVcOnc7DvCfvveBAz6wSigX1Y";

function call(method, path, body, extraHeaders){
  return new Promise((resolve) => {
    const u = new URL(URL_BASE + path);
    const payload = body ? JSON.stringify(body) : null;
    const headers = Object.assign({
      "apikey": KEY,
      "Authorization": "Bearer " + KEY,
      "Content-Type": "application/json"
    }, extraHeaders || {});
    if (payload) headers["Content-Length"] = Buffer.byteLength(payload);

    const started = Date.now();
    const req = https.request({
      hostname: u.hostname, path: u.pathname + u.search, method, headers, timeout: 15000
    }, (res) => {
      let d = "";
      res.on("data", c => d += c);
      res.on("end", () => resolve({ status: res.statusCode, body: d, ms: Date.now()-started }));
    });
    req.on("timeout", () => { req.destroy(); resolve({ status: 0, body: "TIMED OUT after 15s", ms: 15000 }); });
    req.on("error", e => resolve({ status: 0, body: e.code + " - " + e.message, ms: Date.now()-started }));
    if (payload) req.write(payload);
    req.end();
  });
}

function line(){ console.log("-".repeat(62)); }

(async () => {
  console.log("");
  line();
  console.log("  NIDC  -  SUPABASE PUSH TEST");
  line();
  console.log("  Target: " + URL_BASE);
  console.log("  Time:   " + new Date().toString());
  console.log("");

  // 1 - can we reach it at all
  process.stdout.write("  1. Reaching Supabase ............. ");
  const r1 = await call("GET", "/rest/v1/", null);
  if (r1.status === 0) {
    console.log("FAILED");
    console.log("     " + r1.body);
    console.log("");
    console.log("  >> This PC cannot reach Supabase at all.");
    console.log("     Either there is no internet, or the shop firewall is");
    console.log("     blocking supabase.co. That is why nothing is pushing.");
    line(); return;
  }
  console.log("OK  (HTTP " + r1.status + ", " + r1.ms + "ms)");

  // 2 - can we READ
  process.stdout.write("  2. Reading haas_live ............. ");
  const r2 = await call("GET", "/rest/v1/haas_live?select=machine_id,last_update", null);
  if (r2.status >= 200 && r2.status < 300) {
    let rows = [];
    try { rows = JSON.parse(r2.body); } catch(e) {}
    console.log("OK  (" + rows.length + " rows)");
    rows.forEach(r => console.log("       " + r.machine_id + "   last update: " + r.last_update));
  } else {
    console.log("FAILED  (HTTP " + r2.status + ")");
    console.log("     " + r2.body.slice(0,300));
  }

  // 3 - can we WRITE  (this is the one that matters)
  process.stdout.write("  3. Writing a test row ............ ");
  const testRow = [{
    machine_id: "__TEST__",
    machine_name: "connection test",
    status: "offline",
    last_update: new Date().toISOString()
  }];
  const r3 = await call("POST", "/rest/v1/haas_live?on_conflict=machine_id", testRow,
                        { "Prefer": "resolution=merge-duplicates" });
  if (r3.status >= 200 && r3.status < 300) {
    console.log("OK  (HTTP " + r3.status + ")");
    console.log("");
    console.log("  >> The cloud connection is FINE. Pushing works.");
    console.log("     So if the app shows no data, the problem is that the");
    console.log("     bridge is not reaching the MACHINES - not the cloud.");
    console.log("     Run CHECK-BRIDGE.bat to test the machines.");
    await call("DELETE", "/rest/v1/haas_live?machine_id=eq.__TEST__", null);
  } else {
    console.log("FAILED  (HTTP " + r3.status + ")");
    console.log("");
    console.log("     Response from Supabase:");
    console.log("     " + r3.body.slice(0,600));
    console.log("");
    if (r3.status === 401 || r3.status === 403) {
      console.log("  >> The API key is rejected. The key in bridge.js does not");
      console.log("     match the project, or it expired.");
    } else if (r3.status === 404) {
      console.log("  >> Table haas_live does not exist in this project.");
    } else if (r3.status === 400) {
      console.log("  >> Supabase rejected the data. Usually a column in the");
      console.log("     bridge does not exist in the table. The message above");
      console.log("     names the column.");
    } else {
      console.log("  >> Send the response text above and it can be fixed.");
    }
  }
  console.log("");
  line();
  console.log("");
})();
