-- ===================================================================
--  Run just this. One result, one answer.
-- ===================================================================
SELECT
  pg_size_pretty(pg_database_size(current_database()))        AS total_db_size,
  round(pg_database_size(current_database())/1048576.0)       AS db_mb,
  round(pg_database_size(current_database())/1048576.0/500*100) AS pct_of_free_limit;

SELECT relname                                        AS table_name,
       n_live_tup                                     AS live_rows,
       n_dead_tup                                     AS dead_rows,
       CASE WHEN n_live_tup > 0
            THEN round(n_dead_tup::numeric / n_live_tup, 1)
            ELSE NULL END                             AS dead_per_live,
       pg_size_pretty(pg_total_relation_size(relid))  AS size_on_disk,
       last_autovacuum
FROM   pg_stat_user_tables
ORDER  BY pg_total_relation_size(relid) DESC
LIMIT  12;
