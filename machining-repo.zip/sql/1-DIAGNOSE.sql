-- ===================================================================
--  NIDC - STEP 1: find out what is wrong
--  Paste into Supabase dashboard -> SQL Editor -> Run
-- ===================================================================

-- How big is the database, and how much of the free 500 MB is used?
SELECT pg_size_pretty(pg_database_size(current_database())) AS database_size;

-- Which tables are big, and how much is dead weight?
-- "dead_rows" much larger than "live_rows" means bloat - that is the problem.
SELECT relname                        AS table_name,
       n_live_tup                     AS live_rows,
       n_dead_tup                     AS dead_rows,
       pg_size_pretty(pg_total_relation_size(relid)) AS size_on_disk,
       last_autovacuum,
       last_autoanalyze
FROM   pg_stat_user_tables
ORDER  BY pg_total_relation_size(relid) DESC;

-- Is something holding connections open?
SELECT state, count(*) AS connections,
       max(now() - state_change) AS longest_in_this_state
FROM   pg_stat_activity
WHERE  datname = current_database()
GROUP  BY state
ORDER  BY connections DESC;

-- Any query stuck running for a long time?
SELECT pid, state, now() - query_start AS running_for,
       left(query, 90) AS query
FROM   pg_stat_activity
WHERE  datname = current_database()
  AND  state <> 'idle'
  AND  now() - query_start > interval '30 seconds'
ORDER  BY running_for DESC;
