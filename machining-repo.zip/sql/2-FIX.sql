-- ===================================================================
--  NIDC - STEP 2: reclaim the space
--  Run AFTER 1-DIAGNOSE.sql. Safe: deletes no data of yours.
--  VACUUM FULL locks each table for a few seconds. Do it when the
--  floor is quiet, or stop the bridge first.
-- ===================================================================

-- haas_live is rewritten every few seconds, so it bloats the most
VACUUM FULL ANALYZE haas_live;

VACUUM FULL ANALYZE haas_production_log;
VACUUM FULL ANALYZE haas_downtime_log;
VACUUM FULL ANALYZE haas_shift_history;
VACUUM FULL ANALYZE shift_schedules;
VACUUM FULL ANALYZE job_queue;
VACUUM FULL ANALYZE job_photos;

-- Tell Postgres to clean this table far more aggressively from now on,
-- because it is written to constantly.
ALTER TABLE haas_live SET (
  autovacuum_vacuum_scale_factor = 0.0,
  autovacuum_vacuum_threshold    = 50,
  autovacuum_analyze_scale_factor= 0.0,
  autovacuum_analyze_threshold   = 50
);

-- Check the result
SELECT pg_size_pretty(pg_database_size(current_database())) AS database_size_now;

SELECT relname AS table_name, n_live_tup AS live_rows, n_dead_tup AS dead_rows,
       pg_size_pretty(pg_total_relation_size(relid)) AS size_on_disk
FROM   pg_stat_user_tables
ORDER  BY pg_total_relation_size(relid) DESC;
