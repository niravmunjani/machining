-- ===================================================================
--  NIDC - OPTIONAL: trim history you no longer need
--  Only run this if STEP 1 showed the production log is very large.
--  CHECK THE COUNTS FIRST, then uncomment the deletes.
-- ===================================================================

-- How much history is there, and how far back?
SELECT 'haas_production_log' AS table_name, count(*) AS rows,
       min(shift_date) AS oldest, max(shift_date) AS newest
FROM haas_production_log
UNION ALL
SELECT 'haas_downtime_log', count(*), min(shift_date), max(shift_date)
FROM haas_downtime_log;

-- How many rows are older than 90 days?
SELECT count(*) AS rows_older_than_90_days
FROM   haas_production_log
WHERE  shift_date < current_date - 90;

-- ---- Uncomment ONLY after checking the numbers above ----
-- DELETE FROM haas_production_log WHERE shift_date < current_date - 90;
-- DELETE FROM haas_downtime_log   WHERE shift_date < current_date - 90;
-- VACUUM FULL ANALYZE haas_production_log;
-- VACUUM FULL ANALYZE haas_downtime_log;

-- Shift summaries are tiny and worth keeping. Do not delete
-- haas_shift_history - that is what the History and Reports tabs read.
