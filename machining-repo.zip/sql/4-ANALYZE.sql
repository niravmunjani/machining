-- ===================================================================
--  Gather statistics. Safe, fast, changes no data.
--  Your tables have never been analysed, so Postgres has been
--  planning queries blind.
-- ===================================================================
ANALYZE;

-- Now the row counts will be real
SELECT relname AS table_name,
       n_live_tup AS live_rows,
       n_dead_tup AS dead_rows,
       pg_size_pretty(pg_total_relation_size(relid)) AS size_on_disk
FROM   pg_stat_user_tables
WHERE  relname LIKE 'haas%' OR relname IN
       ('shift_schedules','job_queue','job_history','job_photos','workers')
ORDER  BY pg_total_relation_size(relid) DESC;

-- Total database size against the 500 MB free limit
SELECT pg_size_pretty(pg_database_size(current_database())) AS total_size,
       round(pg_database_size(current_database())/1048576.0/500*100,1) AS pct_of_free_limit;

-- Is the bridge actually writing? Should be seconds old.
SELECT machine_id, status, parts_this_shift, last_update,
       round(EXTRACT(EPOCH FROM (now() - last_update))) AS seconds_ago
FROM   haas_live
ORDER  BY machine_id;
