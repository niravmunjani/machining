-- ===================================================================
--  Four entries have a part number where the quantity should be.
--  They inflate every total and average in the app.
--
--  LOOK FIRST. Only run the UPDATE once you are happy.
-- ===================================================================

-- 1) See them
SELECT shift_date, shift_number, station, worker_name,
       left(coalesce(job,''),30) AS job, made
FROM   v_station_shifts
WHERE  made > 2000
ORDER  BY made DESC;

-- 2) What they are doing to your numbers
SELECT 'with the typos'  AS version, sum(made) AS total_pieces
FROM   v_station_shifts WHERE shift_date >= current_date - 180
UNION ALL
SELECT 'without them',   sum(made)
FROM   v_station_shifts WHERE shift_date >= current_date - 180 AND made <= 2000;

-- 3) Fix: blank the made value on those station-shifts so someone
--    can re-enter the real figure. Nothing else is touched.
--
--    Uncomment to run.
--
-- UPDATE shift_schedules s
-- SET    stations = jsonb_set(s.stations::jsonb,
--                             ARRAY[k.key,'partsActual'], '0'::jsonb, false)
-- FROM   jsonb_each(s.stations::jsonb) k
-- WHERE  (k.value->>'partsActual') ~ '^[0-9]+$'
--   AND  (k.value->>'partsActual')::int > 2000;

-- 4) Confirm afterwards
-- SELECT count(*) AS still_over_2000 FROM v_station_shifts WHERE made > 2000;
