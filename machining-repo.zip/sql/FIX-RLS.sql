-- ===================================================================
--  CORS / "failed to load" fix
--  Run in: Supabase dashboard -> SQL Editor
--
--  A table with RLS switched ON but NO policy rejects every request.
--  Depending on where it fails, the browser reports that as a CORS
--  error rather than the real reason. haas_live and haas_shift_history
--  are the two failing in your log, so check them first.
-- ===================================================================

-- STEP 1: which tables are locked with no way in?
SELECT c.relname                         AS table_name,
       c.relrowsecurity                  AS rls_on,
       count(p.policyname)               AS policies,
       CASE WHEN c.relrowsecurity AND count(p.policyname)=0
            THEN '<<<< LOCKED - nothing can read this'
            ELSE 'ok' END                AS verdict
FROM   pg_class c
JOIN   pg_namespace n ON n.oid=c.relnamespace
LEFT   JOIN pg_policies p ON p.schemaname='public' AND p.tablename=c.relname
WHERE  n.nspname='public' AND c.relkind='r'
GROUP  BY c.relname, c.relrowsecurity
ORDER  BY verdict DESC, c.relname;


-- STEP 2: give every app table a read/write policy.
-- Safe to run repeatedly. Only touches tables this app uses.
DO $fix$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'haas_live','haas_production_log','haas_downtime_log','haas_shift_history',
    'shift_schedules','job_queue','job_history','job_photos','station_live',
    'workers','worker_skills','parts'
  ] LOOP
    IF EXISTS (SELECT 1 FROM information_schema.tables
               WHERE table_schema='public' AND table_name=t) THEN
      EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
      EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', t||'_open', t);
      EXECUTE format(
        'CREATE POLICY %I ON public.%I FOR ALL USING (true) WITH CHECK (true)',
        t||'_open', t);
      RAISE NOTICE 'policy set on %', t;
    END IF;
  END LOOP;
END
$fix$;


-- STEP 3: make PostgREST notice the change straight away
NOTIFY pgrst, 'reload schema';


-- STEP 4: confirm nothing is left locked
SELECT c.relname AS table_name,
       count(p.policyname) AS policies
FROM   pg_class c
JOIN   pg_namespace n ON n.oid=c.relnamespace
LEFT   JOIN pg_policies p ON p.schemaname='public' AND p.tablename=c.relname
WHERE  n.nspname='public' AND c.relkind='r' AND c.relrowsecurity
GROUP  BY c.relname
HAVING count(p.policyname)=0;
-- An empty result here means everything is readable.
