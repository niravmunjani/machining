-- ===================================================================
--  NIDC Casting MES - schema
--  Safe to run as many times as you like. Creates nothing twice,
--  deletes no data.
-- ===================================================================

-- ---------- TABLES ----------
CREATE TABLE IF NOT EXISTS jobs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  machine TEXT NOT NULL,
  shop_order TEXT DEFAULT '',
  part TEXT NOT NULL,
  die TEXT DEFAULT '',
  balance INTEGER DEFAULT 0,
  total_on_job INTEGER DEFAULT 0,
  completed INTEGER DEFAULT 0,
  pct_complete NUMERIC(5,3) DEFAULT 0,
  avg_per_shift INTEGER DEFAULT 0,
  shifts_left INTEGER DEFAULT 0,
  priority TEXT DEFAULT 'normal',
  status TEXT DEFAULT 'pending',
  assigned_caster TEXT DEFAULT '',
  assigned_haas TEXT DEFAULT '',
  needs_haas BOOLEAN DEFAULT false,
  needs_paint BOOLEAN DEFAULT false,
  is_down BOOLEAN DEFAULT false,
  notes TEXT DEFAULT '',
  profit_per_unit NUMERIC(10,2) DEFAULT 0,
  due_date DATE,
  shifts JSONB DEFAULT '[[0,0],[0,0],[0,0],[0,0],[0,0],[0,0]]',
  week_start DATE,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS week_schedule (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  week_start DATE NOT NULL,
  week_dates JSONB DEFAULT '[]',
  file_name TEXT DEFAULT '',
  uploaded_by TEXT DEFAULT '',
  notes TEXT DEFAULT '',
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS crew_assignments (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  machine TEXT NOT NULL,
  shift INTEGER NOT NULL DEFAULT 1,
  role TEXT NOT NULL DEFAULT 'operator',
  name TEXT DEFAULT '',
  week_start DATE,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS daily_actuals (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  job_id UUID REFERENCES jobs(id) ON DELETE CASCADE,
  machine TEXT DEFAULT '',
  date DATE NOT NULL,
  shift INTEGER DEFAULT 1,
  actual_pcs INTEGER DEFAULT 0,
  scrap_pcs INTEGER DEFAULT 0,
  good_pcs INTEGER DEFAULT 0,
  hours NUMERIC(5,1) DEFAULT 0,
  notes TEXT DEFAULT '',
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS machine_notes (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  machine TEXT NOT NULL UNIQUE,
  notes TEXT DEFAULT '',
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- ---------- ROW LEVEL SECURITY ----------
ALTER TABLE jobs             ENABLE ROW LEVEL SECURITY;
ALTER TABLE week_schedule    ENABLE ROW LEVEL SECURITY;
ALTER TABLE crew_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_actuals    ENABLE ROW LEVEL SECURITY;
ALTER TABLE machine_notes    ENABLE ROW LEVEL SECURITY;

-- ---------- POLICIES ----------
-- Postgres has no "CREATE POLICY IF NOT EXISTS", so drop first.
-- This is what your error was about.
DROP POLICY IF EXISTS "jobs_open"    ON jobs;
DROP POLICY IF EXISTS "week_open"    ON week_schedule;
DROP POLICY IF EXISTS "crew_open"    ON crew_assignments;
DROP POLICY IF EXISTS "actuals_open" ON daily_actuals;
DROP POLICY IF EXISTS "notes_open"   ON machine_notes;

CREATE POLICY "jobs_open"    ON jobs             FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "week_open"    ON week_schedule    FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "crew_open"    ON crew_assignments FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "actuals_open" ON daily_actuals    FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "notes_open"   ON machine_notes    FOR ALL USING (true) WITH CHECK (true);

-- ---------- REALTIME ----------
-- ALTER PUBLICATION errors if the table is already published, so check first.
DO $pub$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['jobs','crew_assignments','daily_actuals'] LOOP
    IF NOT EXISTS (
      SELECT 1 FROM pg_publication_tables
      WHERE pubname = 'supabase_realtime'
        AND schemaname = 'public'
        AND tablename  = t
    ) THEN
      EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', t);
    END IF;
  END LOOP;
END
$pub$;

-- ---------- updated_at TRIGGERS ----------
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $fn$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$fn$ LANGUAGE plpgsql;

-- Same story as policies: no "IF NOT EXISTS" on CREATE TRIGGER.
DROP TRIGGER IF EXISTS jobs_updated  ON jobs;
DROP TRIGGER IF EXISTS crew_updated  ON crew_assignments;
DROP TRIGGER IF EXISTS notes_updated ON machine_notes;

CREATE TRIGGER jobs_updated  BEFORE UPDATE ON jobs
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER crew_updated  BEFORE UPDATE ON crew_assignments
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER notes_updated BEFORE UPDATE ON machine_notes
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ---------- INDEXES ----------
CREATE INDEX IF NOT EXISTS idx_jobs_machine  ON jobs(machine);
CREATE INDEX IF NOT EXISTS idx_jobs_week     ON jobs(week_start);
CREATE INDEX IF NOT EXISTS idx_jobs_status   ON jobs(status);
CREATE INDEX IF NOT EXISTS idx_crew_machine  ON crew_assignments(machine);
CREATE INDEX IF NOT EXISTS idx_crew_week     ON crew_assignments(week_start);
CREATE INDEX IF NOT EXISTS idx_actuals_date  ON daily_actuals(date);
CREATE INDEX IF NOT EXISTS idx_actuals_job   ON daily_actuals(job_id);

-- ---------- CONFIRM ----------
SELECT t.table_name,
       (SELECT count(*) FROM pg_policies p
         WHERE p.schemaname='public' AND p.tablename=t.table_name) AS policies
FROM information_schema.tables t
WHERE t.table_schema='public'
  AND t.table_name IN ('jobs','week_schedule','crew_assignments',
                       'daily_actuals','machine_notes')
ORDER BY t.table_name;
