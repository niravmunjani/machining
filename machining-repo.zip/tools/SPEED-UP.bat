@echo off
title NIDC - Speed Up
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed.  https://nodejs.org
  pause
  exit /b
)
node speed-up.js
pause
