"""
NIDC Scheduler - Offline Bundler (Python version)
Run once on any PC with internet:
  python bundle-offline.py   (or double-click it)

Output: NIDC_Scheduler_OFFLINE.html
That file works with NO internet (except Supabase data sync).
"""

import urllib.request
import os
import sys

LIBS = [
    (
        '<script crossorigin src="https://unpkg.com/react@18/umd/react.production.min.js"></script>',
        'https://unpkg.com/react@18.3.1/umd/react.production.min.js',
        'React'
    ),
    (
        '<script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>',
        'https://unpkg.com/react-dom@18.3.1/umd/react-dom.production.min.js',
        'ReactDOM'
    ),
    (
        '<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js"></script>',
        'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.39.3/dist/umd/supabase.min.js',
        'Supabase'
    ),
    (
        '<script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>',
        'https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js',
        'XLSX'
    ),
    (
        '<script src="https://unpkg.com/@babel/standalone@7.23.6/babel.min.js"></script>',
        'https://unpkg.com/@babel/standalone@7.23.6/babel.min.js',
        'Babel'
    ),
]

FONT_TAG = '<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"/>'
FONT_REPLACE = '<style>body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif}</style>'

def fetch(url, name):
    print(f'  Downloading {name}...', end='', flush=True)
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=60) as r:
        # Follow redirects handled automatically
        data = r.read().decode('utf-8')
    kb = len(data) // 1024
    print(f' OK ({kb}KB)')
    return data

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    input_file = os.path.join(script_dir, 'NIDC_Machining_Scheduler.html')
    output_file = os.path.join(script_dir, 'NIDC_Scheduler_OFFLINE.html')

    if not os.path.exists(input_file):
        print('ERROR: NIDC_Machining_Scheduler.html not found in the same folder as this script.')
        input('Press Enter to exit...')
        sys.exit(1)

    print('Reading HTML file...')
    with open(input_file, 'r', encoding='utf-8') as f:
        html = f.read()

    # Remove Google Fonts (requires internet)
    html = html.replace(FONT_TAG, FONT_REPLACE)

    print('\nDownloading and bundling libraries...\n')
    for (script_tag, url, name) in LIBS:
        try:
            code = fetch(url, name)
            inlined = f'<script>\n{code}\n</script>'
            if script_tag in html:
                html = html.replace(script_tag, inlined)
            else:
                print(f'  WARNING: Could not find {name} script tag in HTML.')
        except Exception as e:
            print(f' FAILED: {e}')
            print('  Check your internet connection and try again.')
            input('Press Enter to exit...')
            sys.exit(1)

    print('\nWriting offline file...')
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html)

    size_mb = os.path.getsize(output_file) / 1024 / 1024
    print(f'\n[OK] Done!')
    print(f'   Output: NIDC_Scheduler_OFFLINE.html ({size_mb:.1f}MB)')
    print(f'   Open this file in Chrome or Edge — no internet needed.')
    print(f'   Note: Saving/loading shift data still needs internet (Supabase).')
    input('\nPress Enter to close...')

if __name__ == '__main__':
    main()
