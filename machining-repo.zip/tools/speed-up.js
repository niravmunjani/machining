/* =====================================================================
   NIDC - Make the app load fast
   Compiles the app ahead of time so the browser does not need Babel.
   Removes a 2.4 MB download and all the compiling work on every load.

   Run:  node speed-up.js
   ===================================================================== */
const fs   = require("fs");
const path = require("path");
const { execSync } = require("child_process");

const FILES = ["NIDC_Machining_Scheduler.html", "NIDC_Mobile.html"];

function findBabel(){
  try { require.resolve("@babel/core"); return true; } catch(e) {}
  console.log("Installing the compiler (one time, needs internet)...\n");
  try {
    execSync("npm install --no-audit --no-fund --silent @babel/core @babel/preset-react",
             { cwd: __dirname, stdio: "inherit" });
    return true;
  } catch(e){
    console.log("\nCould not install the compiler.");
    console.log("Check internet, or run manually:");
    console.log("   npm install @babel/core @babel/preset-react\n");
    return false;
  }
}

function speedUp(file){
  const src = path.join(__dirname, file);
  if (!fs.existsSync(src)) { console.log("  SKIP  " + file + "  (not in this folder)"); return; }

  let html = fs.readFileSync(src, "utf8");
  const before = Buffer.byteLength(html);

  const openTag = html.match(/<script\s+type="text\/babel"[^>]*>/);
  if (!openTag){ console.log("  SKIP  " + file + "  (already compiled)"); return; }

  const start = html.indexOf(openTag[0]) + openTag[0].length;
  const end   = html.lastIndexOf("</script>");
  const jsx   = html.slice(start, end);

  process.stdout.write("  " + file + "  compiling " +
    Math.round(jsx.length/1024) + " KB ... ");

  const babel = require("@babel/core");
  let out;
  try {
    out = babel.transformSync(jsx, {
      presets: [[require("@babel/preset-react"), { runtime: "classic" }]],
      compact: false, comments: false, babelrc: false, configFile: false,
    }).code;
  } catch(e){
    console.log("FAILED");
    console.log("\n  The app code has a syntax error Babel will not accept:");
    console.log("  " + e.message.split("\n")[0] + "\n");
    return;
  }

  // swap the babel block for plain javascript
  html = html.slice(0, html.indexOf(openTag[0]))
       + "<script>\n" + out + "\n</script>"
       + html.slice(end + "</script>".length);

  // babel itself is no longer needed in the browser
  html = html.replace(/\s*<script[^>]*babel[^>]*><\/script>/gi, "");

  const outFile = src.replace(/\.html$/, "_FAST.html");
  fs.writeFileSync(outFile, html, "utf8");

  const after = Buffer.byteLength(html);
  console.log("OK");
  console.log("     saved: " + path.basename(outFile));
  console.log("     page  " + Math.round(before/1024) + " KB -> " +
              Math.round(after/1024) + " KB,  plus 2.4 MB of Babel no longer downloaded");
}

console.log("");
console.log("=".repeat(58));
console.log("  NIDC  -  SPEED UP");
console.log("=".repeat(58));
console.log("");
if (findBabel()){
  FILES.forEach(speedUp);
  console.log("");
  console.log("Done. Upload the _FAST.html files instead of the originals.");
  console.log("They behave identically, they just start much quicker.");
}
console.log("");
